// Databricks notebook source

spark.conf.set("com.databricks.training.module-name", "spark-sql")

val courseAdvertisements = scala.collection.mutable.Map[String,(String,String,String)]()

spark.conf.set("com.databricks.training.suppress.untilStreamIsReady", "true")
spark.conf.set("com.databricks.training.suppress.stopAllStreams", "true")
spark.conf.set("com.databricks.training.suppress.moduleName", "true")
spark.conf.set("com.databricks.training.suppress.lessonName", "true")
spark.conf.set("com.databricks.training.suppress.username", "true")
spark.conf.set("com.databricks.training.suppress.userhome", "true")
spark.conf.set("com.databricks.training.suppress.workingDir", "true")

displayHTML("Preparing learning environment...")

// COMMAND ----------

// MAGIC %run "./Common-Notebooks/Common"

// COMMAND ----------

def createTableFrom(tableName:String, filesPath:String) = {
  spark.sql(s"""CREATE TABLE IF NOT EXISTS ${tableName} USING parquet OPTIONS (path "${filesPath}")""");
  spark.sql(s"uncache TABLE ${tableName}")
  // println(s"""Created the table ${tableName} from ${filesPath}""")
}

createTableFrom("People10M", "dbfs:/mnt/training/dataframes/people-10m.parquet")
createTableFrom("SSANames", "dbfs:/mnt/training/ssn/names.parquet")
createTableFrom("CityData", "dbfs:/mnt/training/City-Data.parquet")
createTableFrom("IPGeocode", "dbfs:/mnt/training/ip-geocode.parquet")

def createDatabricksBlog() = {
  val tableName = "DatabricksBlog"
  val fileName = "dbfs:/mnt/training/databricks-blog.json"

  spark.sql(s"""
  CREATE TABLE IF NOT EXISTS ${tableName}
  USING json
  OPTIONS (
    path "${fileName}",
    inferSchema "true"
  )""")

  spark.sql(s"uncache TABLE ${tableName}")

  // println(s"""Created the table ${tableName} from ${fileName}""")
}
createDatabricksBlog()

def createAirlinePlane() = {
  val tableName = "AirlinePlane"
  val fileName =  "dbfs:/mnt/training/asa/planes/plane-data.csv"

  spark.sql(s"""
  CREATE TABLE IF NOT EXISTS ${tableName} (`tailnum` STRING, `type` STRING, `manufacturer` STRING, `issue_date` STRING, `model` STRING, `status` STRING, `aircraft_type` STRING, `engine_type` STRING, `year` STRING)
  USING csv 
  OPTIONS (
    header "true",
    delimiter ",",
    inferSchema "false",
    path "${fileName}"
  )""")

  spark.sql(s"uncache TABLE ${tableName}")

  // println(s"""Created the table ${tableName} from ${fileName}""")
}
createAirlinePlane()

def createAirlineFlight() {
  val tableName = "AirlineFlight"
  val fileName =  "dbfs:/mnt/training/asa/flights/small.csv"

  spark.sql(s"""
  CREATE TABLE IF NOT EXISTS ${tableName} (`Year` INT, `Month` INT, `DayofMonth` INT, `DayOfWeek` INT, `DepTime` STRING, `CRSDepTime` INT, `ArrTime` STRING, `CRSArrTime` INT, `UniqueCarrier` STRING, `FlightNum` INT, `TailNum` STRING, `ActualElapsedTime` STRING, `CRSElapsedTime` INT, `AirTime` STRING, `ArrDelay` STRING, `DepDelay` STRING, `Origin` STRING, `Dest` STRING, `Distance` INT, `TaxiIn` INT, `TaxiOut` INT, `Cancelled` INT, `CancellationCode` STRING, `Diverted` INT, `CarrierDelay` STRING, `WeatherDelay` STRING, `NASDelay` STRING, `SecurityDelay` STRING, `LateAircraftDelay` STRING)
  USING CSV OPTIONS (
    header="true", 
    delimiter=",", 
    inferSchema="false", 
    path="${fileName}")
  """)

  spark.sql(s"uncache TABLE ${tableName}")

  // println(s"""Created the table ${tableName} from ${fileName}""")
}
createAirlineFlight()

def createBikeSharingDay() = {
  val tableName = "BikeSharingDay"
  val fileName = "dbfs:/mnt/training/bikeSharing/data-001/day.csv"

  spark.sql(s"""
  CREATE TABLE IF NOT EXISTS ${tableName}
  USING csv
  OPTIONS (
    path "${fileName}",
    inferSchema "true",
    header "true"
  )""")

  spark.sql(s"uncache TABLE ${tableName}")

  // println(s"""Created the table ${tableName} from ${fileName}""")
}
createBikeSharingDay()

try {
  dbutils.fs.unmount("/mnt/temp-training")
} catch {
  case e:Exception => () // ignored
}

allDone(courseAdvertisements)
