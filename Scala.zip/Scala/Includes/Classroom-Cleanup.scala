// Databricks notebook source

try {
  dbutils.fs.unmount("/mnt/temp-training")
} catch {
  case e:Exception => () // ignored
}

spark.sql("DROP DATABASE IF EXISTS junk CASCADE")
spark.sql("DROP DATABASE IF EXISTS databricks CASCADE")

classroomCleanup(daLogger, courseType, username, moduleName, lessonName, true)

// COMMAND ----------

showStudentSurvey()
