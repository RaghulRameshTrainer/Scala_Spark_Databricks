// Databricks notebook source
// MAGIC 
// MAGIC %md-sandbox
// MAGIC 
// MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
// MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
// MAGIC </div>

// COMMAND ----------

// MAGIC %md
// MAGIC # Aggregations, JOINs and Nested Queries
// MAGIC Apache Spark&trade; and Databricks&reg; allow you to create on-the-fly data lakes.
// MAGIC 
// MAGIC ## In this lesson you:
// MAGIC * Use basic aggregations.
// MAGIC * Correlate two data sets with a join
// MAGIC * Use subselects
// MAGIC 
// MAGIC ## Audience
// MAGIC * Primary Audience: Data Analysts
// MAGIC * Additional Audiences: Data Engineers and Data Scientists
// MAGIC 
// MAGIC ## Prerequisites
// MAGIC * Web browser: **Chrome**
// MAGIC * A cluster configured with **8 cores** and **DBR 6.2**
// MAGIC * Familiarity with <a href="https://www.w3schools.com/sql/" target="_blank">ANSI SQL</a> is required

// COMMAND ----------

// MAGIC %md
// MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Setup
// MAGIC 
// MAGIC For each lesson to execute correctly, please make sure to run the **`Classroom-Setup`** cell at the<br/>
// MAGIC start of each lesson (see the next cell) and the **`Classroom-Cleanup`** cell at the end of each lesson.

// COMMAND ----------

// MAGIC %run "./Includes/Classroom-Setup"

// COMMAND ----------

// MAGIC %md
// MAGIC <iframe  
// MAGIC src="//fast.wistia.net/embed/iframe/b9v2h8520r?videoFoam=true"
// MAGIC style="border:1px solid #1cb1c2;"
// MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
// MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
// MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
// MAGIC <div>
// MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/b9v2h8520r?seo=false">
// MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
// MAGIC </div>

// COMMAND ----------

// MAGIC %md-sandbox
// MAGIC ## Basic aggregations
// MAGIC 
// MAGIC Using <a href="https://spark.apache.org/docs/latest/api/python/pyspark.sql.html#module-pyspark.sql.functions" target="_blank">built-in Spark functions</a>, you can aggregate data in various ways. 
// MAGIC 
// MAGIC Run the cell below to compute the average of all salaries in the `People10M` table.
// MAGIC 
// MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> By default, you get a floating point value.

// COMMAND ----------

// MAGIC %md
// MAGIC <iframe  
// MAGIC src="//fast.wistia.net/embed/iframe/1g8ch2l14y?videoFoam=true"
// MAGIC style="border:1px solid #1cb1c2;"
// MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
// MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
// MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
// MAGIC <div>
// MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/1g8ch2l14y?seo=false">
// MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
// MAGIC </div>

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT avg(salary) AS averageSalary 
// MAGIC FROM People10M

// COMMAND ----------

// MAGIC %md
// MAGIC Convert that value to an integer using the SQL `round()` function. See
// MAGIC <a href="http://spark.apache.org/docs/latest/api/python/pyspark.sql.html#pyspark.sql.functions.round" class="text-info">the PySpark documentation for <tt>round()</tt></a>
// MAGIC for more details.

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT round(avg(salary)) AS averageSalary 
// MAGIC FROM People10M

// COMMAND ----------

// MAGIC %md
// MAGIC In addition to the average salary, what are the maximum and minimum salaries?

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT max(salary) AS max, min(salary) AS min, round(avg(salary)) AS average 
// MAGIC FROM People10M

// COMMAND ----------

// MAGIC %md
// MAGIC ## Joining two tables
// MAGIC 
// MAGIC Correlate the data in two data sets using a SQL join. 
// MAGIC 
// MAGIC The `People10M` table has 10 million names in it. 
// MAGIC 
// MAGIC > How many of the first names appear in Social Security data files? 
// MAGIC 
// MAGIC To find out, use the `SSANames` table with first name popularity data from the United States Social Security Administration. 
// MAGIC 
// MAGIC For every year from 1880 to 2014, `SSANames` lists the first names of people born in that year, their gender, and the total number of people given that name. 
// MAGIC 
// MAGIC By joining the `People10M` table with `SSANames`, weed out the names that aren't represented in the Social Security data.
// MAGIC 
// MAGIC (In a real application, you might use a join like this to filter out bad data.)

// COMMAND ----------

// MAGIC %md
// MAGIC <iframe  
// MAGIC src="//fast.wistia.net/embed/iframe/9quo6ugich?videoFoam=true"
// MAGIC style="border:1px solid #1cb1c2;"
// MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
// MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
// MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
// MAGIC <div>
// MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/9quo6ugich?seo=false">
// MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
// MAGIC </div>

// COMMAND ----------

// MAGIC %md
// MAGIC Start by taking a quick peek at what `SSANames` looks like.

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT * FROM SSANames

// COMMAND ----------

// MAGIC %md
// MAGIC Next, get an idea of how many distinct names there are in each of our tables, with a quick count of distinct names.

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT count(DISTINCT firstName) 
// MAGIC FROM People10M

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT count(DISTINCT firstName)
// MAGIC FROM SSANames

// COMMAND ----------

// MAGIC %scala
// MAGIC 
// MAGIC class transform  extends java.io.Serializable
// MAGIC {
// MAGIC    def generatemailid(i:String,j:String):String=
// MAGIC     {
// MAGIC     return i.trim().capitalize.replace(" ",".").replace("-",".")+j+"@inceptez.com"
// MAGIC     }
// MAGIC     
// MAGIC     def getcategory(i:String):String=i.trim() match
// MAGIC     {
// MAGIC       case "Police officer"|"Politician"|"Judge"=> "Government"
// MAGIC       case "Automotive mechanic"|"Economist"|"Loan officer"=> "Worker"
// MAGIC       case "Psychologist"|"Veterinarian"|"Doctor"=> "Medical"
// MAGIC       case "Civil engineer"|"Computer hardware engineer"|"Engineering technician"=> "Engineering"  
// MAGIC       case _ => "Others"
// MAGIC     }
// MAGIC }
// MAGIC 
// MAGIC val obj=new transform()
// MAGIC spark.udf.register("udfgeneratemailid",obj.generatemailid _)
// MAGIC val emaildata=spark.sql("""SELECT firstName,middleName,lastName,birthdate,gender,ssn,udfgeneratemailid(firstName,salary)
// MAGIC           FROM People10M LIMIT 10""")
// MAGIC emaildata.createOrReplaceTempView("Cust_Email")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC SELECT * FROM Cust_Email

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT year(birthdate), count(1) as total FROM  Cust_Email GROUP BY 1 ORDER BY 1

// COMMAND ----------

// MAGIC %md
// MAGIC By introducing two more temporary views, each one consisting of distinct names, the join will be easier to read/write.

// COMMAND ----------

// MAGIC %sql
// MAGIC CREATE OR REPLACE TEMPORARY VIEW SSADistinctNames AS 
// MAGIC   SELECT DISTINCT firstName AS ssaFirstName 
// MAGIC   FROM SSANames;
// MAGIC 
// MAGIC CREATE OR REPLACE TEMPORARY VIEW PeopleDistinctNames AS 
// MAGIC   SELECT DISTINCT firstName 
// MAGIC   FROM People10M

// COMMAND ----------

// MAGIC %md
// MAGIC Next, join the two tables together to get the answer.

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT firstName 
// MAGIC FROM PeopleDistinctNames 
// MAGIC INNER JOIN SSADistinctNames ON firstName = ssaFirstName

// COMMAND ----------

display(dbutils.fs.ls("/databricks-datasets/COVID/coronavirusdataset/"))

// COMMAND ----------

val patientRDD = spark.read.option("header","true").format("csv").option("inferSchema","true").load("dbfs:/databricks-datasets/COVID/coronavirusdataset/PatientInfo.csv")
patientRDD.createOrReplaceTempView("Patient_Table")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC SELECT  country,  count(1) AS total from Patient_Table WHERE country != 'Korea' GROUP BY 1 ORDER BY 2 DESC

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT  country,  count(1) AS total from Patient_Table WHERE country != 'Korea' GROUP BY 1 ORDER BY 2 DESC

// COMMAND ----------

val df1=spark.sql("SELECT case WHEN infected_by IS null THEN 99999999 ELSE infected_by END AS infected_by_modified, * FROM Patient_Table")
df1.createOrReplaceTempView("Patient_Table_Final")

// COMMAND ----------

val IndiaDF=spark.sql("SELECT * FROM Patient_Table_Final WHERE country = 'India'")
val IndiaDF1=IndiaDF.drop("infected_by")
IndiaDF1.show()
// IndiaDF.createOrReplaceTempView("IndiaPatientInfo")
// IndiaDF.write.mode("overwrite").format("csv").save("dbfs:/databricks-datasets/COVID/coronavirusdataset/IndiaPatientInfo")

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC 
// MAGIC SELECT * FROM Patient_Table_Final WHERE country = 'India'

// COMMAND ----------

display(dbutils.fs.ls("/databricks-datasets/COVID/coronavirusdataset/"))

// COMMAND ----------

// MAGIC %md
// MAGIC How many are there?

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT count(*) 
// MAGIC FROM PeopleDistinctNames 
// MAGIC INNER JOIN SSADistinctNames ON firstName = ssaFirstName

// COMMAND ----------

// MAGIC %md
// MAGIC ## Nested Queries
// MAGIC 
// MAGIC Joins are not the only way to solve the problem. 
// MAGIC 
// MAGIC A sub-select works as well.

// COMMAND ----------

// MAGIC %md
// MAGIC <iframe  
// MAGIC src="//fast.wistia.net/embed/iframe/hs7vn1o0et?videoFoam=true"
// MAGIC style="border:1px solid #1cb1c2;"
// MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
// MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
// MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
// MAGIC <div>
// MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/hs7vn1o0et?seo=false">
// MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
// MAGIC </div>

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT count(firstName) 
// MAGIC FROM PeopleDistinctNames
// MAGIC WHERE firstName IN (
// MAGIC   SELECT ssaFirstName FROM SSADistinctNames
// MAGIC )

// COMMAND ----------

// MAGIC %md-sandbox
// MAGIC ## Exercise 1
// MAGIC 
// MAGIC In the tables above, some of the salaries in the `People10M` table are negative. 
// MAGIC 
// MAGIC These salaries represent bad data. 
// MAGIC 
// MAGIC Your job is to convert all the negative salaries to positive ones, and then sort the top 20 people by their salary.
// MAGIC 
// MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** See the Apache Spark documentation, <a href="https://spark.apache.org/docs/latest/api/python/pyspark.sql.html#module-pyspark.sql.functions" target="_blank">built-in functions</a>.

// COMMAND ----------

// MAGIC %md
// MAGIC ### Step 1
// MAGIC Create a temporary view called `PeopleWithFixedSalaries`, where all the negative salaries have been converted to positive numbers.

// COMMAND ----------

// MAGIC %sql
// MAGIC -- TODO
// MAGIC 
// MAGIC FILL_IN

// COMMAND ----------

// TEST - Run this cell to test your solution.

val belowZero = spark.read.table("PeopleWithFixedSalaries").where("salary < 0").count()
dbTest("SQL-L3-belowZero", 0, belowZero)

println("Tests passed!")

// COMMAND ----------

// MAGIC %md
// MAGIC ### Step 2
// MAGIC 
// MAGIC Starting with the table `PeopleWithFixedSalaries`, create another view called `PeopleWithFixedSalariesSorted` where:
// MAGIC 0. The data set has been reduced to the first 20 records
// MAGIC 0. The records are sorted by the column `salary` in ascending order

// COMMAND ----------

// MAGIC %sql
// MAGIC -- TODO
// MAGIC 
// MAGIC FILL_IN

// COMMAND ----------

// TEST - Run this cell to test your solution.

val resultsDF = spark.sql("select salary from PeopleWithFixedSalariesSorted")
dbTest("SQL-L3-count", 20, resultsDF.count())

val results = resultsDF.collect().map(r => r.getAs[Int](0))

dbTest("SQL-L3-fixedSalaries-0", 2, results(0))
dbTest("SQL-L3-fixedSalaries-1", 3, results(1))
dbTest("SQL-L3-fixedSalaries-2", 4, results(2))

dbTest("SQL-L3-fixedSalaries-10", 19, results(10))
dbTest("SQL-L3-fixedSalaries-11", 19, results(11))
dbTest("SQL-L3-fixedSalaries-12", 20, results(12))

dbTest("SQL-L3-fixedSalaries-17", 28, results(17))
dbTest("SQL-L3-fixedSalaries-18", 30, results(18))
dbTest("SQL-L3-fixedSalaries-19", 31, results(19))

println("Tests passed!")

// COMMAND ----------

// MAGIC %md
// MAGIC ## Exercise 2
// MAGIC 
// MAGIC As a refinement, assume that all salaries under $20,000 represent bad rows and filter them out.
// MAGIC 
// MAGIC Additionally, categorize each person's salary into $10K groups.

// COMMAND ----------

// MAGIC %md
// MAGIC ### Step 1
// MAGIC Create a temporary view called `PeopleWithFixedSalaries20K` where:
// MAGIC 0. Start with the table `PeopleWithFixedSalaries`
// MAGIC 0. The data set excludes all records where salaries are below $20K
// MAGIC 0. The data set includes a new column called `salary10k`, that should be the salary in groups of 10,000. For example:
// MAGIC   * A salary of 23,000 should report a value of "2"
// MAGIC   * A salary of 57,400 should report a value of "6"
// MAGIC   * A salary of 1,231,375 should report a value of "123"

// COMMAND ----------

// MAGIC %sql
// MAGIC -- TODO
// MAGIC 
// MAGIC FILL_IN

// COMMAND ----------

// TEST - Run this cell to test your solution.

val below2K = spark.sql("select * from PeopleWithFixedSalaries20K where salary < 20000").count()
dbTest("SQL-L3-count-salaries", 0, below2K)

val resultsDF = spark.sql("select salary10k, count(*) as total from PeopleWithFixedSalaries20K  group by salary10k order by salary10k, total limit 5")
val results = resultsDF.collect().map(r => (r.getAs[Double](0).toInt, r.getAs[Long](1)) ).map(t => s"${t._1} w/${t._2}")

dbTest("SQL-L3-countSalaries-0", "2 w/43792",   results(0))
dbTest("SQL-L3-countSalaries-1", "3 w/212630",  results(1))
dbTest("SQL-L3-countSalaries-2", "4 w/536536",  results(2))
dbTest("SQL-L3-countSalaries-3", "5 w/1055261", results(3))
dbTest("SQL-L3-countSalaries-4", "6 w/1623248", results(4))

println("Tests passed!")

// COMMAND ----------

// MAGIC %md
// MAGIC ## Exercise 3
// MAGIC 
// MAGIC Using the `People10M` table, count the number of females named Caren who were born before March 1980. 

// COMMAND ----------

// MAGIC %md
// MAGIC ### Step 1
// MAGIC Starting with the table `People10M`, create a temporary view called `Carens` where:
// MAGIC 0. The result set has a single record
// MAGIC 0. The data set has a single column named `total`
// MAGIC 0. The result counts only 
// MAGIC   * Females (`gender`)
// MAGIC   * First Name is "Caren" (`firstName`)
// MAGIC   * Born before March 1980 (`birthDate`)

// COMMAND ----------

// MAGIC %sql
// MAGIC -- TODO
// MAGIC 
// MAGIC FILL_IN

// COMMAND ----------

// TEST - Run this cell to test your solution.

val rows = spark.sql("SELECT total FROM Carens").collect()
dbTest("SQL-L3-carens-len", 1, rows.length)
dbTest("SQL-L3-carens-total", 750, rows(0).getAs[Long]("total"))

print("Tests passed!")

// COMMAND ----------

display(dbutils.fs.ls("/databricks-datasets/COVID/coronavirusdataset/"))

// COMMAND ----------

// create a DF : (df1) for the file : dbfs:/databricks-datasets/COVID/coronavirusdataset/Region.csv

val df1 = spark.read.format("csv").option("header","true").option("inferSchema","true").load("dbfs:/databricks-datasets/COVID/coronavirusdataset/Region.csv")
df1.createOrReplaceTempView("Region_Info")
df1.show(2)


// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC SELECT province, sum(elementary_school_count) as total_elementary_school, 
// MAGIC sum(kindergarten_count) as total_kindergarten,
// MAGIC sum(university_count) as total_university
// MAGIC FROM Region_Info
// MAGIC GROUP BY province
// MAGIC ORDER BY province

// COMMAND ----------

// MAGIC %sql
// MAGIC 
// MAGIC SELECT latitude,longitude, count(1) FROM Region_Info GROUP BY 1,2

// COMMAND ----------

// MAGIC %md
// MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Cleanup<br>
// MAGIC 
// MAGIC Run the **`Classroom-Cleanup`** cell below to remove any artifacts created by this lesson.

// COMMAND ----------

// MAGIC %run "./Includes/Classroom-Cleanup"

// COMMAND ----------

// MAGIC %md
// MAGIC ## Next Steps
// MAGIC 
// MAGIC * Do the extra [Challenge Exercise]($./Optional/SSQL 03L - Joins Aggregations Lab).
// MAGIC * Or start one of the following lessons:
// MAGIC   - [Accessing Data - Amazon S3]($./SSQL 04a - Accessing Data - Amazon S3).
// MAGIC   - [Accessing Data - Azure Blob]($./SSQL 04b - Accessing Data - Azure Blob).

// COMMAND ----------

// MAGIC %md
// MAGIC ## Additional Topics & Resources
// MAGIC 
// MAGIC * <a href="https://docs.databricks.com/spark/latest/spark-sql/index.html" target="_blank">Spark SQL Reference</a>
// MAGIC * <a href="http://spark.apache.org/docs/latest/sql-programming-guide.html" target="_blank">Spark SQL, DataFrames and Datasets Guide</a>
// MAGIC * <a href="https://databricks.com/blog/2017/08/31/cost-based-optimizer-in-apache-spark-2-2.html" target="_blank">Cost-based Optimizer in Apache Spark 2.2</a>

// COMMAND ----------

// MAGIC %md-sandbox
// MAGIC &copy; 2020 Databricks, Inc. All rights reserved.<br/>
// MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
// MAGIC <br/>
// MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>