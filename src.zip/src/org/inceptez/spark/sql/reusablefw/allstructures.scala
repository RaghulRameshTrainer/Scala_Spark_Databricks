package org.inceptez.spark.sql.reusablefw


  
case class Auction(auctionid: String, bid: Float, bidtime: Float, bidder: String, bidderrate:
Integer, openbid: Float, price: Float, item: String, daystolive: Integer)

case class Auction1(auctionid: String, bid: Float, bidtime: Float, bidder: String, bidderrate:
Integer, openbid: Float, price: Float, item: String, daystolive: Integer)