package org.inceptez.spark.sql

/* PREREQUISITES BEFORE RUNNING THIS CODE
******************************************
1. mysql is started:
sudo service mysqld start
2. hive remote metastore is started
hive --service metastore
3. Ensure to replace /home/hduser/sparkdata folder with the sparkdata from the GDrive  
4. Ensure to replace /home/hduser/hive/data folder with the hivedata from the GDrive  
*/


/*URL References: 
https://spark.apache.org/docs/latest/api/sql/index.html
https://spark.apache.org/docs/2.0.1/api/java/org/apache/spark/sql/DataFrameReader.html
https://spark.apache.org/docs/2.3.0/api/sql/
*/
 
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql._
import org.apache.spark.sql.SparkSession;
//import org.apache.spark.sql._;
case class customercaseclass(custid:Int,custfname:String,custlname:String,custage:Int,custprofession:String);

object objsql1  {

  def main(args:Array[String])
  {

/*//SQLContext is a class and is used for initializing the functionalities of Spark SQL. 
//SparkContext class object (sc) is required for initializing SQLContext class object.
 
val conf = new SparkConf().setAppName("SQL1").setMaster("local[*]")
val sc = new SparkContext(conf)
val sqlc = new SQLContext(sc)
//val hqlc=new org.apache.spark.sql.hive.HiveContext(sc)
sc.setLogLevel("ERROR");*/

/*Spark 2.x, we have a new entry point for DataSet and Dataframe API’s called as Spark Session.
SparkSession is essentially combination of SQLContext, HiveContext and future StreamingContext. 
All the API’s available on those contexts are available on spark session also. 
Spark session internally has a spark context for actual computation.*/

val spark=SparkSession.builder().appName("SQL End to End App").master("local[*]").enableHiveSupport().
config("spark.sql.sources.partitionOverwriteMode","dynamic").
getOrCreate();
val sc=spark.sparkContext
sc.setLogLevel("error")
val sqlc=spark.sqlContext

// Various ways of creating dataframes

println("************ EXTRACT TRANSFORM LOAD (ETL using Spark SQL) ************")


println("************ EXTRACT ************")
println(""" 1.Create dataframe using case class  with toDF and createdataframe functions (Reflection)
2.create dataframe from collections type such as structtype and fields    
3.creating dataframe using read method using csv  and other modules like json, orc, parquet etc.
4.Create dataframe from hive.
5.Create dataframe from DB using jdbc (ora,td,sqlserv,redshift,athena,phoenix) """);

//Create DF/DS -> RDD->DF/DS, modules 
//apply schema using -> 
//Native Scala type -case class, 
//SQL types - (struct type, inferschema) 

println("""UseCase1 : Understanding Creation of DF and DS from a Schema RDD, 
and differentiting between DF and DS wrt schema bounding""")
    
/* Create dataframe using case class  with toDF and createdataframe functions*/
println("Create dataframe using case class (defined outside the main method) using Reflection")
    
//step 1: import the implicits for using toDF, toDS or createdataset
import sqlc.implicits._
    
//step 2: create rdd
val filerdd = sc.textFile("file:/home/hduser/hive/data/custs")

    
//step 3: create case class (outside main method) based on the structure of the data - Create SchemaRDD
    
val rdd1 = filerdd.map(x => x.split(",")).filter(x => x.length == 5)
.map(x => customercaseclass(x(0).toInt,x(1),x(2),x(3).toInt,x(4)))

val rddreject1 = filerdd.map(x => x.split(",")).filter(x => x.length != 5)


println("Creating Dataframe and DataSet")

val filedf = rdd1.toDF();
//dataframe=dataset[row]
//dataset=dataset[caseclass schema + row]
val fileds=rdd1.toDS();
    
val rowrdd=filedf.rdd; // sql types, scala type is not preserved
val schemardd=fileds.rdd // oops scala types, sql type is preserved
    

val filedf1 = sqlc.createDataFrame(rdd1) //implicits is not required for the createDataFrame function.
val fileds1 = sqlc.createDataset(rdd1)
    
filedf.printSchema()
filedf.show(10,false)
    
println("DSL Queries on DF")
fileds.select("*").where("custprofession='Pilot' and custage>35").show(10);

println("DSL Queries on DS")
fileds.select("*").where("custprofession='Pilot' and custage>35").show(10);

//.filter("custprofession='Pilot' and custage>35")
  
println("Registering Dataset as a temp view and writing sql queries")
fileds.createOrReplaceTempView("datasettempview")
spark.sql("select * from datasettempview where custprofession='Pilot' and custage>35").show(5,false)

println("Done with the use case of understanding Creation of DF and DS from an RDD, and differentiting between DF and DS wrt schema bounding")

println("********** Usecase2: Reading multiple files in multiple folders with header and footer **********")
// Reading multiple files kept in multiple folders
    
/* 
 * Create the below files in the file system
cd ~
mkdir sparkdir1
mkdir sparkdir2
cp ~/sparkdata/usdata.csv ~/sparkdir1/
cp ~/sparkdata/usdata.csv ~/sparkdir1/usdata1.csv
cp ~/sparkdata/usdata.csv ~/sparkdir2/usdata2.csv
cp ~/sparkdata/usdata.csv ~/sparkdir2/usdata3.csv
wc -l ~/sparkdir1/usdata1.csv
500 /home/hduser/sparkdir1/usdata1.csv
*/
    
val dfmultiple=spark.read.option("header","true").option("inferSchema",true).csv("file:///home/hduser/sparkdir*/*.csv")
//val dfmultiple=spark.read.option("header","true").option("inferSchema",true).csv("file:///home/hduser/sparkdir1/*.csv","file:///home/hduser/sparkdata/*.csv")
println(" Four files with 500 lines with each 1 header, after romoved 499*4=1996 ")
    
println(dfmultiple.count)

//creating dataframe from read method using csv

// Removal of trailer if any
/* Download the following files from the GDrive We have kept or execute the below steps:
 
cp /home/hduser/hive/data/custs /home/hduser/hive/data/custsmodified
vi /home/hduser/hive/data/custsmodified
4000000,Apache,Spark,11,
4000001,Kristina,Chung,55,Pilot
4000001,Kristina,Chung,55,Pilot
4000002,Paige,Chen,77,Actor
4000003,Sherri,Melton,34,Reporter
4000004,Gretchen,Hill,66,Musician
,Karen,Puckett,74,Lawyer

echo "trailer_data:end of file" >> /home/hduser/hive/data/custsmodified
    wc -l /home/hduser/hive/data/custsmodified
    10002

     */


println("UseCase3 : Learning of possible transformations performed on the given data")

println("************ TRANSFORM ************")
println("*************** Data Munging -> Validation, Cleansing, Scrubbing, De Duplication and Replacement of Data to make it in a usable format *********************")
println("*************** Data Enrichment -> Rename, Add, Concat, Casting of Fields, Handling Nulls/Blanks *********************")
println("*************** Data Customization & Processing -> Apply User defined functions and reusable frameworks *********************")
println("*************** Data Processing, Analysis & Summarization -> filter, transformation, Grouping, Aggregation *********************")
println("*************** Data Wrangling -> Lookup, Join, Enrichment *********************")

//val struct=StructType(Array(StructField))
// val customdfcsv1=spark.read.option("mode","dropmalformed").schema("struct").csv("file:/home/hduser/hive/data/custsmodified")
/*val dfcsv1 = spark.read.format("csv").
option("mode","dropmalformed").
option("inferSchema",true).
load("file:/home/hduser/hive/data/custsmodified")//.toDF("cid","fname","lname","ag","prof")
*/

// If we think from a Datalake data management perspective, the processing of data from Aquire -> cure -> process -> store 
// across different layers of the Datalake
// Raw Zone (raw data/uncleaned data)

val dfcsv1 = spark.read.
//option("header",true).option("delimiter",",")
option("mode","dropmalformed").
option("inferSchema",true).
csv("file:/home/hduser/hive/data/custsmodified")//.toDF("cid","fname","lname","ag","prof")

// allow all data and then drop malformed data manually later
val dfcsvall = spark.read.
option("mode","permissive").
csv("file:/home/hduser/hive/data/custsmodified")//.toDF("cid","fname","lname","ag","prof")

// or to remove footer...
// val finaldfcsv=dfcsvall.limit(dfcsv1.count.toInt-1)
val all5colsdf=dfcsvall.where("_c4 is null")
val rejectallless5colsdf=dfcsvall.where("_c4 is null or _c3 is null or _c2 is null  or _c1 is null or _c0 is null")


println(" Final count After removing the trailer record of the original file ")
println(dfcsv1.count)

dfcsv1.sort('_c0.desc).show(1)
dfcsv1.sort($"_c0".desc).show(1)
import org.apache.spark.sql.functions.{concat,col,lit,udf,max,min}
dfcsv1.sort(col("_c0").desc).show(1)
dfcsv1.sort("_c0").show(1)

println("Do some basic performance improvements, we will do more later in a seperate discussion ")
// Interview Question - Can we repartition or cache the DF or DS?
val dfcsv=dfcsv1.repartition(4)

// how to get the number of partitions of a DF
println(dfcsv.rdd.getNumPartitions);

dfcsv.cache()

println("Initial count of the dataframe ")
println(dfcsv.count())

// Raw to Curated zone (apply cleanup and curation logic) 
println("""*************** 1. Data Munging (Cleanup) / Wrangling (Preparing the data for consumption is for 
  Data engineers/Analytics user) -> 
  Preprocessing, Preparation, Validation, Cleansing, Scrubbing, De Duplication, Regulation and Replacement 
  of Data to make it in a usable format *********************""")

//Writing DSL 
// NULL Handling - Data in the file with empty value will be represented as nulls  
println("Dropping the null records specific to some columns custid is null using where clause")
//val rejectallless5colsdf=dfcsvall.where("_c0 is null")

println("Remove the record with null in any of the column ")
val dfcsvallcolumnswithnull=dfcsv.na.drop;

println("Remove the record with null in one or more columns ")
val dfcsva=dfcsv.na.drop(Array("_c0"));

println("Replace the null with default values for one or more columns ")
val dfcsvb=dfcsva.na.fill("UNKNOWN", Array("_c4"));

println("Replace the key with the respective values in the columns ")
val map=Map("Actor"->"Stars","Reporter"->"Media person","Musician"->"Instrumentist")
//val countrycd=Map("US"->"USA","AMERICA"->"USA","STATES"->"USA")
val dfcsvc=dfcsvb.na.replace(Array("_c4"), map);

println("Records with Duplicate")
println(dfcsvc.count)

println("Dropping Duplicate records ")
val dfcsvd=dfcsvc.distinct()//.dropDuplicates()

println("De Duplicated count")
println(dfcsvd.count())
dfcsvd.sort("_c0").show(10);


//Important- default partions to 200 after shuffle happens because of some wide transformation spark sql uses in the background
//or after the shuffle happens as a part of wide transformation (groupby,join) the partition will be increased to 200

spark.sqlContext.setConf("spark.sql.shuffle.partitions","1");
dfcsvd.sort("_c0").show(10);

println("We can write all the above code in a single line DSL also as given below")
//dfcsvcleanse=dfcsv.na.drop(Array("_c0")).na.fill("UNKNOWN", Array("_c4")).na.replace(Array("_c4"), map).distinct().sort("_c0").show(10)

//Writing equivalent SQL
dfcsv.createOrReplaceTempView("dfcsvview");

val dfcsvcleanse=sqlc.sql("""select distinct _c0,_c1,_c2,_c3,case when _c4 is null then "UNKNOWN" 
when _c4="Actor" then "Stars" when _c4="Reporter" then "Media person" 
when _c4="Musician" then "Instrumentist"
else _c4 end as _c4 
from  dfcsvview 
where _c0 is not null
order by _c0 """)
//if you have to use an alternative for "na.drop" which is costly when u use SQL ie: where_c1 is not null or _c2 is not null .... _c1000 is not null

println(dfcsvcleanse.count)
dfcsvcleanse.sort("_c0").show(10)

println("Current Schema of the DF")
dfcsvd.printSchema();
println("Current Schema of the tempview DF")
dfcsvcleanse.printSchema();
 

import org.apache.spark.sql.functions.{concat,col,lit,udf,max,min}
 
//placeholder for defining columns as column type itself in a df ($"_c2",col("_c2"),'_c2)
// placeholder for defining columns as string type in a df ("")

println("""*************** 2. Data Enrichment/Curation -> 
                Rename, Derive, Add (literals),Merging, Casting of Fields, Remove unwanted fields*********************"""")
//DSL
val dfcsvd1=dfcsvd.
withColumnRenamed("_c0", "custid").
withColumn("IsAPilot",col("_c4").contains("Pilot")).
withColumn("Typeofdata",lit("CustInfo")).
withColumn("fullname",concat('_c1,lit(" "),$"_c2")).
withColumn("Stringage",$"_c3".cast("String")).
drop("_c1","_c2","_c3").withColumnRenamed("_c4","profession")

dfcsvd1.printSchema
dfcsvd1.sort("custid").show(5,false)

dfcsvd.createOrReplaceTempView("customer")

println("Converting DSL Equivalent SQL queries")

println("SQL EQUIVALENT to DSL") // Interview question-what is the difference between case expression in scala/sql and case class
spark.sql(""" select _c0 as custid,_c4 as profession, case when _c4 like ('%Pilot%') then true else false end as IsAPilot,
                         'CustInfo' as Typeofdata,concat(_c1," ",_c2) as fullname,
                          cast(_c3 as string) as stringage
                          from customer """).sort(col("custid").asc).show(5,false)

println("Another way of renaming column names ")
// define or change column names and datatype->  Case class using -> as[], structtype(Array(structfields)) -> schema(),
//                                               col names -> toDF(all columns),withcolumnrenamed

val dfcsvd1renamed=dfcsvd1.toDF("custid","profession","pilotornot","TypeofData","fullname","age")

println("Renamed dataframe with proper names to handle further steps easily ")
dfcsvd1renamed.printSchema
                          
//val classobj=new org.inceptez.spark.allfunctions

println("*************** 3. Data Customization & Processing -> Apply User defined functions and reusable frameworks *********************")      
                  
println("Applying UDF in DSL")

// how to make use of an existing scala method in a DSL -> once object is created 
// -> convert the method into udf or register as udf
// -> apply the udf to your df columns

println("create an object reusableobj to Instantiate the cleanup class present in org.inceptez.spark.sql.reusable pkg")
  
val reusableobj=new org.inceptez.spark.sql.reusablefw.cleanup;

// Syntax for Converting a Scala method to udf or register as udf  

//val udfnamefordsl=udf(scalamethod _) // Only applicable for DSL (udfnamefordsl)
//val udfnamefordsl=spark.udf.register("udfnameforsql",scalamethod _) // Applicable for DSL (udfnamefordsl) or can be used for  SQL also (udfnameforsql)


println("Convert the scala method to UDF to use in Dataframe DSL")
val udftrim = udf(reusableobj.trimupperdsl _) // only applicable for DSL
val dfudfapplied1=dfcsvd1renamed.withColumn("trimmedname",udftrim('fullname))
dfudfapplied1.printSchema;
dfudfapplied1.show(5,false)

//or
spark.udf.register("udftrimsql",reusableobj.trimupperdsl _) //applicable only for SQL

//or
val udftrimdsl=spark.udf.register("udftrimsql",reusableobj.trimupperdsl _) //applicable with both DSL and SQL
//for rdd -> reusableobj.trimupperdsl
//for dsl -> udftrimdsl
//for sql -> udftrimsql

dfcsvd1renamed.select(udftrimdsl('fullname).alias("udffullnm")).show(2,false)

//Interview question - Difference between Select(SQL),SelectExpr(DSL), Select(DSL)  
println("Applying UDF in Select (SQL), SelectExpr(DSL), Select(DSL)")

//Using Select SQL
println("Applying UDF in Select SQL")
dfcsvd1renamed.createOrReplaceTempView("udfview")
sqlc.sql("select custid as cid,profession,cast(udftrimsql(fullname) as string) as fullname from udfview ").show

//Using Select Expression allows you to write sql select syntax in DSL itself without registering a tempview 
println("Applying UDF in Select Expression DSL")
dfcsvd1renamed.selectExpr("custid as cid","profession","cast(udftrimsql(fullname) as string) as fullname").show

//or
println("Applying UDF in Select DSL")
dfcsvd1renamed.select($"custid".alias("cid"),$"profession",udftrimdsl($"fullname").cast("string").alias("fullname")).show

//raw zone -> cleanup (munging) -> Transformations (Business logics) -> Curated zone -> Transformations (join, metrics) -> discovery zone

println("""*************** 4. Data Processing, Analysis & Summarization -> 
                          filter, Grouping, Aggregation, transformation, categorization & Categorized Aggregation *********************""")

val dfgrouping = dfudfapplied1.where("cast(age as int)>5").groupBy("profession").
agg(max("age").alias("maxage"),min("age").alias("minage"))
println("dfgrouping")

dfgrouping.show(5,false)

// Persist the Data anywhere inbetween as per the need, not needed to always show.
//dfgrouping.write.json("hdfs path")

println("Converting DSL Equivalent SQL queries")

dfudfapplied1.createOrReplaceTempView("customer")

val dfsqltransformedaggr=spark.sql("""select profession,max(age) as maxage,min(age) as minage 
                                      from customer 
                                      where cast (age as int) >5
                                      group by profession""")
                  
dfsqltransformedaggr.show(5,false)
// Persist the Data anywhere inbetween as per the need, not needed to always show.
//dfsqltransformedaggr.write.saveAsTable("hivetablename")    


// Transformation (Generate mailids)-> categorizing (Categorize the profession group using udf)-> aggregating the categorized data
println("Again Applying transformation using UDFs + Example for spark sql udf function registration with methods")

// method in rdds/scala def/val, UDF In dsl udf(methodname), UDF Register in SQL spark.udf.register

val reusableobj1=new org.inceptez.spark.sql.reusablefw.transform;
//val udfgeneratemailid=udf(reusableobj1.generatemailid _) // if need to use only in dsl
spark.udf.register("udfgeneratemailid",reusableobj1.generatemailid _) // if need to use only in sql
val udfgetcategorydsl=spark.udf.register("udfgetcategory",reusableobj1.getcategory _) // if need to use both in DSL and in sql

//Transform
val dfsqltransformed=
spark.sql("""select custid,profession,pilotornot,typeofdata,age,trimmedname,udfgeneratemailid(fullname,custid) as mailid,
                         udfgetcategory(profession) as cat
                         from customer""")
             
dfsqltransformed.show(10,false)  
      
dfsqltransformed.createOrReplaceTempView("customertransformed")

//Group & Aggregate
spark.sql("""select cat,max(age) as maxage,min(age) as minage 
                  from customertransformed 
                  where age>5
                  group by cat""").show(5,false)

// Or Combined query 1 and 2 in a single Query
// transformation -> categorizing -> aggregating -> schema migration -> persistance

                  spark.sql("""select cat,max(age) as maxage,min(age) as minage 
                  from (select custid,profession,pilotornot,typeofdata,age,trimmedname,udfgeneratemailid(fullname,custid) as mailid,
                         udfgetcategory(profession) as cat
                         from customer) as customertransformed 
             where age>5
                  group by cat""").coalesce(1).write.mode("overwrite").json("file:///home/hduser/discoverydata")                 

import org.apache.spark.sql.types._
  //  val structtype1=StructType(Array(StructField("txnid",IntegerType,false),StructField("txnid",IntegerType,false)))   ;           

/*All Possible ways to define column names/type ->
 ********************************************** 
1. reflection(case class)
2. Schema(structtype(structfield)),
3. if we have header option(header,true)+option(inferschema,true)
4. toDF("colnames")
5. orc/parquet/avro/json/jdbc/xml
6. To rename/change type only few columns - 
   withColumnRenamed/withColumn newcolname/alias newcolumname + drop oldcolname, for datatype cast*/

val txns=spark.read.option("inferschema",true).
option("header",false).option("delimiter",",").
csv("file:///home/hduser/hive/data/txns").
toDF("txnid","dt","cid","amt","category","product","city","state","transtype")
    
txns.show(10);

// Finally transform the data from Curation zone to discovery/consumption zone 
// (Data Wrangling - Lookup, Join, Enrichment) -> reporting user consumption

println("""*************** 5. Data Wrangling (Preparing the data for consumption is for Reporting/Analytics end users) 
  -> Lookup, Join, Enrichment *********************""")

// Joins in Dataframe DSL

//txns.join(txns,txns("txnid")===txns("txnid")&&txns("cid")===txns("cid"),"inner").show
  
//txns.join(dfsqltransformed,dfsqltransformed("custid")===txns("cid"),"inner").show(10)


txns.createOrReplaceTempView("transwith1yeardata");

println("""Lookup and Enrichment Scenario in temp views - 
           Lookup in the 1 year transaction data and identify the old or new customeers""")

val dflookupsql = spark.sql("""select a.custid,b.amt,b.transtype,
  case when b.transtype is null then "new/more than 1 year customer" else "repeating customers" end as TransactionorNot
  from customertransformed a left join transwith1yeardata b
  on a.custid=b.cid
  """)
  
println("Lookup dataset")
dflookupsql.show(10,false) // you can store in some tables/nosqls

println("Join Scenario in temp views for Denormolization")  
val dfjoinsql = spark.sql("""select a.custid,a.profession,a.pilotornot,a.typeofdata,age,mailid,cat,
  b.amt,b.transtype,b.city,b.product,b.dt 
  from customertransformed a inner join transwith1yeardata b
  on a.custid=b.cid""")

println("Enriched final dataset, lets assume its stored in Hive")
dfjoinsql.show(10,false)

dfjoinsql.createOrReplaceTempView("joinedviewhive")

println(""" In the Discovery/Consumption layer following are the sample queries run by the Business users 
  to understand the consumer pattern""")

  println("""Important Interview Question - Analytical/Window Queries -> 
Identify the 2nd recent transaction performed by the customers """)
  //custid,name,dt,amt
  // 1,IRFAN,10 AM,20,1
        // 1,IRFAN,11 AM,10,2
  // 1,IRFAN,12 PM,30,3
  // 1,IRFAN,1 PM,40,4
  // 2,SELVA,9 AM,10
  // 2,SELVA,10 AM,30
  
val dfjoinsqlkeygen = spark.sql("""select * from (
                               select custid,row_number() over(partition by custid order by dt desc) as transorder,
                               cat,profession,city,product,amt,dt
                               from joinedviewhive) as joineddata
                               where transorder=2""")

println("Key generated final dataset")
dfjoinsqlkeygen.show(10,false)

println(" Aggregation on the joined data set")    
val dfjoinsqlagg = spark.sql("""select city,cat,profession,transtype,sum(amt) as sum_amt,avg(amt) as avg_amt 
                             from joinedviewhive 
                             group by city,cat,profession,transtype
                             having sum(amt)>50""")

println("Aggregated final dataset")
dfjoinsqlagg.show(10,false)

println("************ LOAD ************")
    
println("*************** 6. Data Persistance -> Discovery, Outbound, Reports, exports, Schema migration  *********************")

println("Writing in JSON Format")
dfjoinsqlkeygen.write.mode("overwrite").json("hdfs://localhost:54310/user/hduser/custjson")

println("We will see later Writing to mysql/any db/any nosql/any cloud storage/any cloud db")

val prop=new java.util.Properties();
prop.put("user", "root")
prop.put("password", "root")

dfjoinsqlagg.write.mode("overwrite").jdbc("jdbc:mysql://localhost/custdb", "customeraggreports",prop )

println("Writing to Hive Partition table")
//sql hive table write
//spark.sql("create table customerhive1() partitioned by (dt as date)")
//spark.sql("insert overwrite into table customerhive1 partition(dt)  select * from joinedview")
// hive query to create a managed/external table
//spark.sql("drop table if exists default.customerhive2")
//dfjoinsql.createOrReplaceTempView("dfjoinsqltempview")
//spark.sql("create external table default.customerhive1 ()")
//spark.sql("insert into default.customerhive1 ")

//DSL hive table write
//dfjoinsql.write.option("mode","overwrite").partitionBy("dt").saveAsTable("default.customerhive2")      
dfjoinsqlagg.write.mode(SaveMode.Overwrite).partitionBy("cat").saveAsTable("default.customerhivecat")

//sql hive table read
spark.sql("""select count(1) as cnt from default.customerhivecat""").show

//DSL hive table read
println(spark.read.table("default.customerhivecat").count())      

  }
  
}













