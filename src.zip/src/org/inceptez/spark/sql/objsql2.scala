package org.inceptez.spark.sql

/* PREREQUISITES BEFORE RUNNING THIS CODE
******************************************
1. mysql is started:
sudo service mysqld start
2. hive remote metastore is started
hive --service metastore
3. Ensure to replace /home/hduser/sparkdata folder with the sparkdata from the GDrive  
4. Ensure to replace /home/hduser/hive/data folder with the data from the GDrive  
5. Enabling Spark UI for Eclipse program run the below lines
mkdir -p /tmp/spark-events
start-history-server.sh

* */

import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql._;
//case class customer(custid:Int,custfname:String,custlname:String,custage:Int,custprofession:String)
    
object objsql2 {
case class transcls (transid:String,transdt:String,custid:String,salesamt:Float,category:String,prodname:String,state:String,city:String,payment:String)
case class customer (custid:Int,firstname:String,lastname:String,city:String,age:Int,createdt:String,transactamt:Long)

  def main(args:Array[String])
  {
/*
SQLContext is a class and is used for initializing the functionalities of Spark SQL. 
SparkContext class object (sc) is required for initializing SQLContext class object.
 */
    /*val conf = new SparkConf().setAppName("SQL1").setMaster("local[*]")
    val sc = new SparkContext(conf)
    val sqlc = new SQLContext(sc)
    sc.setLogLevel("ERROR");
*/
/*Spark 2.x, we have a new entry point for DataSet and Dataframe API’s called as Spark Session.
SparkSession is essentially combination of SQLContext, HiveContext and future StreamingContext. 
All the API’s available on those contexts are available on spark session also. 
Spark session internally has a spark context for actual computation.*/

 
println("We are going to understand options to acquire and store the hetrogeneous data from hetrogenous sources and stores")
// unstructured/structured/semi struct, fs, db (RDBMS/Hive datastore), dfs, cloud, nosql, message queues, sockets, streaming files
// volume, variety, velocity
// spark streaming, spark config, pkg and deployment, PT

// Enabling Spark UI for Eclipse program
//mkdir -p /tmp/spark-events
// start-history-server.sh

val spark=SparkSession.builder().appName("Sample sql app").master("local[*]")
.config("spark.history.fs.logDirectory", "file:///tmp/spark-events")
.config("spark.eventLog.dir", "file:////tmp/spark-events")
.config("spark.eventLog.enabled", "true")
.config("hive.metastore.uris","thrift://localhost:9083")
.config("spark.sql.warehouse.dir","hdfs://localhost:54310/user/hive/warehouse")
.enableHiveSupport()
.getOrCreate();

spark.sparkContext.setLogLevel("error")

val sqlc=spark.sqlContext;

//CSV READ/WRITE 
println("Reading csv format")
val dfcsv=spark.read.option("delimiter",",").option("inferschema","true").option("header","true").
option("quote","\"").option("escape","-").option("ignoreLeadingWhiteSpace","true").
option("ignoreTrailingWhiteSpace","true").option("nullValue","na").option("nanValue","0").
option("timestampFormat","yyyy-MM-dd'T'HH:mm:ss.SSSZZ").option("dateFormat","yyyy-MM-dd").
option("maxCharsPerColumn","1000").option("mode","dropmalformed").csv("file:///home/hduser/sparkdata/sales.csv")

//Convert the date from default yyyy-mm-dd to different format dd/mm/yyyy using date_format function

import org.apache.spark.sql.functions._
dfcsv.select(date_format(col("dt"),"MM-dd-yyyy")).show
dfcsv.show(5,false)

/* You can set the following CSV-specific options to deal with CSV files:

    sep/delimiter (default ,): sets the single character as a separator for each field and value.
    encoding (default UTF-8): decodes the CSV files by the given encoding type.
    quote (default "): sets the single character used for escaping quoted values where the separator can be part of the value. 
    If you would like to turn off quotations, you need to set not null but an empty string.
    escape (default \): sets the single character used for escaping quotes inside an already quoted value.
    comment (default empty string): sets the single character used for skipping lines beginning with this character. By default, it is disabled.
    header (default false): uses the first line as names of columns.
    inferSchema (default false): infers the input schema automatically from data. It requires one extra pass over the data.
    ignoreLeadingWhiteSpace (default false): defines whether or not leading whitespaces from values being read should be skipped.
    ignoreTrailingWhiteSpace (default false): defines whether or not trailing whitespaces from values being read should be skipped.
    nullValue (default empty string): sets the string representation of a null value. 
                                      Since 2.0.1, this applies to all supported types including the string type.
    nanValue (default NaN): sets the string representation of a non-number" value.
    positiveInf (default Inf): sets the string representation of a positive infinity value.
    negativeInf (default -Inf): sets the string representation of a negative infinity value.
    dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. 
    Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
    timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format.Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type.
    java.sql.Timestamp.valueOf() and java.sql.Date.valueOf() or ISO 8601 format.
    maxColumns (default 20480): defines a hard limit of how many columns a record can have.
    maxCharsPerColumn (default 1000000): defines the maximum number of characters allowed for any given value being read.
    maxMalformedLogPerPartition (default 10): sets the maximum number of malformed rows Spark will log for each partition. Malformed records beyond this number will be ignored.
    mode (default PERMISSIVE): allows a mode for dealing with corrupt records during parsing.
        PERMISSIVE : sets other fields to null when it meets a corrupted record. When a schema is set by user, it sets null for extra fields.
        DROPMALFORMED : ignores the whole corrupted records.
        FAILFAST : throws an exception when it meets corrupted records.
*/

// Permissive mode to handle corrupted data with initially string type then convert to right type by casting
import org.apache.spark.sql.types._
val dfcsvpermissive=spark.read.option("delimiter",",").
option("header","true").option("primitivesAsString",true).
option("quote","\"").option("escape","-").option("ignoreLeadingWhiteSpace","true").
option("ignoreTrailingWhiteSpace","true").option("nullValue","na").option("nanValue","0").
option("timestampFormat","yyyy-MM-dd'T'HH:mm:ss.SSSZZ").option("dateFormat","yyyy-MM-dd").
option("maxCharsPerColumn","1000").option("mode","permissive").
csv("file:///home/hduser/sparkdata/salescorrupted.csv")

val dfcsvpermissive1=dfcsvpermissive.na.fill("9999-01-01", Array("dt"));
import sqlc.implicits._;
val dfcsvcustomschema=dfcsvpermissive1.select($"productid",$"productname",$"stdcost".cast("double"),
    $"stdprice".cast("double"),$"effdt".cast("timestamp"),$"dt".cast("date"))


// Formatting of Date in the source with the format of mm-dd-yyyy to the right format yyyy-mm-dd
    
val dfcsvdiffdtfmt=spark.read.option("delimiter",",").option("inferschema","true").option("header","true").
option("quote","\"").option("escape","-").option("ignoreLeadingWhiteSpace","false").
option("ignoreTrailingWhiteSpace","false").option("nullValue","na").option("nanValue","0").
option("timestampFormat","yyyy-MM-dd'T'HH:mm:ss.SSSZZ").option("dateFormat","yyyy-MM-dd").
option("maxCharsPerColumn","1000").option("mode","dropmalformed").
csv("file:///home/hduser/sparkdata/salesdt.csv")

dfcsvdiffdtfmt.printSchema()
dfcsvdiffdtfmt.show(10)

import java.text.SimpleDateFormat;
val fmtsourcefilehas=new SimpleDateFormat("MM-dd-yyyy") // closure

//If i want to use a udf in spark DSL
// 1. need a scala method has to be created or invoked
// 2. convert the scala method from step1 to udf so we can make use in the DSL 
//    (OR) register the scala method from step1 to udf by using udf.regiser("name",methodname _) ,  so we can make use in the SQL
// 3. We can lavishly use the step2 udf in DSL or SQL

def fmtdt(dtcol:String)={
  val parseddt=fmtsourcefilehas.parse(dtcol);
  new java.sql.Date(parseddt.getTime())
}

import org.apache.spark.sql.functions.{concat,col,lit,udf,max,min}
val fmtdtudf=udf(fmtdt _)
val dfout=dfcsvdiffdtfmt.select(col("productid").alias("prodid"),col("productname").alias("prodname"),fmtdtudf(col("dt")).alias("dt"))
dfout.show


println("Writing in csv format")
dfout.coalesce(1).write.mode("overwrite").option("header","true").
option("dateFormat","yyyy-MM-dd HH:mm:ss").option("nullValue","null").
option("delimiter","~").option("compression","gzip").partitionBy("dt").csv("hdfs://localhost:54310/user/hduser/csvdataout")

spark.read.option("header","true").option("delimiter","~").csv("hdfs://localhost:54310/user/hduser/csvdataout").show(5,false)



/* You can set the following CSV-specific option(s) for writing CSV files:

    sep (default ,): sets the single character as a separator for each field and value.
    quote (default "): sets the single character used for escaping quoted values where the separator can be part of the value.
    escape (default \): sets the single character used for escaping quotes inside an already quoted value.
    escapeQuotes (default true): a flag indicating whether values containing quotes should always be enclosed in quotes. 
    Default is to escape all values containing a quote character.
    quoteAll (default false): A flag indicating whether all values should always be enclosed in quotes. Default is to only escape values 
    containing a quote character.
    header (default false): writes the names of columns as the first line.
    nullValue (default empty string): sets the string representation of a null value.
    compression (default null): compression codec to use when saving to file. This can be one of the known case-insensitive shorten names (none, bzip2, gzip, lz4, snappy and deflate).
    dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
    timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type.
*/

//JSON READ/WRITE {{""[],}}
println("Reading in json format")
val dfjson=spark.read.option("prefersDecimal","true").option("allowUnquotedFieldNames","true").
option("allowSingleQuotes","true").option("allowNumericLeadingZeros","true").option("mode","permissive").
option("timestampFormat","yyyy-MM-dd HH:mm:ss").option("dateFormat","yyyy-MM-dd").
option("columnNameOfCorruptRecord", "corruptedjsondata").
json("file:///home/hduser/sparkdata/ebayjson.json")

//different way to read any df (json/csv/jdbc/hive)
val dfjson1=spark.read.format("json").option("prefersDecimal","true").option("allowUnquotedFieldNames","true").
option("allowSingleQuotes","true").option("allowNumericLeadingZeros","true").option("mode","permissive").
option("timestampFormat","yyyy-MM-dd HH:mm:ss").option("dateFormat","yyyy-MM-dd").
option("columnNameOfCorruptRecord", "corruptedjsondata").
load("file:///home/hduser/sparkdata/ebayjson.json")

dfjson.show(5,false)
/* You can set the following JSON-specific options to deal with non-standard JSON files:

    primitivesAsString (default false): infers all primitive values as a string type
    prefersDecimal (default false): infers all floating-point values as a decimal type. If the values do not fit in decimal, then it infers them as doubles.
    allowComments (default false): ignores Java/C++ style comment in JSON records
    allowUnquotedFieldNames (default false): allows unquoted JSON field names
    allowSingleQuotes (default true): allows single quotes in addition to double quotes
    allowNumericLeadingZeros (default false): allows leading zeros in numbers (e.g. 00012)
    allowBackslashEscapingAnyCharacter (default false): allows accepting quoting of all character using backslash quoting mechanism
    mode (default PERMISSIVE): allows a mode for dealing with corrupt records during parsing.
        PERMISSIVE : sets other fields to null when it meets a corrupted record, and puts the malformed string into a new field configured by columnNameOfCorruptRecord. When a schema is set by user, it sets null for extra fields.
        DROPMALFORMED : ignores the whole corrupted records.
        FAILFAST : throws an exception when it meets corrupted records.
    columnNameOfCorruptRecord (default is the value specified in spark.sql.columnNameOfCorruptRecord): allows renaming the new field having malformed string created by PERMISSIVE mode. This overrides spark.sql.columnNameOfCorruptRecord.
    dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
    timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type.
*/

println("Writing in json format")
dfjson.select(col("auctionid"),col("dt").cast("date")).coalesce(1).write.mode("overwrite").option("compression","bzip2").
option("timestampFormat","yyyy-MM-dd HH:mm:ss").
option("dateFormat","dd-MM-yyyy").json("hdfs://localhost:54310/user/hduser/jsonout")

spark.read.json("hdfs://localhost:54310/user/hduser/jsonout").show(5,false)

/* You can set the following JSON-specific option(s) for writing JSON files:

    compression (default null): compression codec to use when saving to file. This can be one of the known case-insensitive shorten names (none, bzip2, gzip, lz4, snappy and deflate).
    dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
    timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type.
*/

// can u connect and pull/push the data into some xyz db using spark?
/// yes provided if the db provides support for some jdbc driver
// then we have to get that jdbc jar file and copy to respective spark jar dir or use it along with your program
// JDBC READ/WRITE

import sqlc.implicits._
println("Creating dataframe using jdbc connector for DB")

// If you want to start in REPL
// spark-shell --jars file:///home/hduser/install/mysql-connector-java.jar

// wanted to use --query in spark as like sqoop
val customquery="(select * from customer where transactamt>10000) tblquery"

val df1 = spark.read.format("jdbc").option("url", "jdbc:mysql://localhost/custdb").
option("driver", "com.mysql.jdbc.Driver").option("dbtable", customquery).option("user", "root").
option("password", "root").load()

/*val prop=new java.util.Properties();
prop.put("user", "root")
prop.put("password", "root")

val df2 = spark.read.option("driver", "com.mysql.jdbc.Driver").option("dbtable", "customer").option("user", "root").
option("password", "root").jdbc("jdbc:mysql://localhost/custdb","customer",prop)*/
       
       println("custom query with trasamt>10000 output")
       df1.show(10,false)
       
    // import --split-by custid -m 3 ,1, 20000, 1 -> 1-6500, 6501-13000, > 13000
val dsdb = spark.read.format("jdbc").
        option("url", "jdbc:mysql://localhost/custdb").
       option("driver", "com.mysql.jdbc.Driver").
       option("dbtable", "customer").
       option("user", "root").
       option("password", "root").
       option("columnname","custid"). // --split-by
       option("lowerBound",1).  //--boundary-query
       option("upperBound",30000).
       option("numPartitions",3). // --num-mappers 3,-m 3
       load().as[customer]
// actual data is 25000 -> q1 (10k)-> custid between 1 and 10000 ,  q2 (10k recs)-> custid between 10001 and 20000 , q3 (5k records)->  custid > 20000
// cid -1 to 10000 -> 1 to 3333 (conn1), 3334 -> 6666 (conn1) , > 6666 (conn3 - 8333) -> 15000
  dsdb.show(5,false)
  val dfdb=dsdb.toDF();

// read data from a db as rdd
  val schemardddb=dsdb.rdd;
dfdb.cache();

/*  url - JDBC database url of the form jdbc:subprotocol:subname.
    table - Name of the table in the external database.
    columnName - the name of a column of integral type that will be used for partitioning.
    lowerBound - the minimum value of columnName used to decide partition stride.
    upperBound - the maximum value of columnName used to decide partition stride.
    numPartitions - the number of partitions. This, along with lowerBound (inclusive), upperBound (exclusive), form partition strides for generated WHERE clause expressions used to split the column columnName evenly.
    connectionProperties - JDBC database connection arguments, a list of arbitrary string tag/value. Normally at least a "user" and "password" property should be included. "fetchsize" can be used to control the number of rows per fetch.
*/
println("Writing to mysql")

val prop=new java.util.Properties();
prop.put("user", "root")
prop.put("password", "root")
prop.put("driver","com.mysql.jdbc.Driver")

dfdb.write.mode("overwrite").jdbc("jdbc:mysql://localhost/custdb","customerspark",prop)


//HIVE READ/WRITE
println("Writing to hive")
// 1. Can we create an external table in spark hive? yes by using sql option and not by using saveastable option
// 2. if i have a df/ds/rdd, how to store in hive using spark? either convert the df into tempview and do insert select 
// or do saveastable with few limitations or write the output in json/orc/parquet/csv/avro any format in hdfs 
// and create an ext table with the proper properties mentioning the location then do msck repair or alter table add partition.

dfdb.createOrReplaceTempView("dfdbview")
spark.sql("use default")
spark.sql("drop table if exists dfdbviewhive");
spark.sql("create external table default.dfdbviewhive(id int,name string) location 'hdfs://localhost:54310/user/hduser/dfdbviewhive'")
spark.sql("insert into default.dfdbviewhive select custid,firstname from dfdbview")

dfdb.select("*").write.mode("overwrite").saveAsTable("default.customermysql")    

//I can store the data into hive table in spark own serialized format, this cant be read in hive cli
dsdb.write.mode(SaveMode.Overwrite).partitionBy("city").saveAsTable("default.customermysqldscity")

spark.sql("drop table if exists default.dfdbviewhive")

println("Displaying hive data")
// you can read in spark the partitioned table created by spark function called partitinBy
val hivedf=spark.read.table("default.customermysqldscity")

// You can read hive table using read.table function of spark also
val hivedf1=spark.read.table("default.customermysql")

// You can read a hive table using native hive QL
val hivedf2=spark.sql("select * from default.customermysql");

println("Validate the count of the data loaded from RDBMS to Hive - RECONCILATION")
println("Schema of RDBMS table")
dfdb.printSchema();
println("Schema of Hive table")
hivedf.printSchema();
//100, 99

val auditobj=new org.inceptez.spark.sql.reusablefw.audit;
if (auditobj.reconcile(dfdb,hivedf)==1)
{
  spark.sqlContext.setConf("hive.exec.dynamic.partition","true"); 
  spark.sqlContext.setConf("hive.exec.dynamic.partition.mode","nonstrict");  
  println("Hive Data load reconcilation success, running rest of the steps")
spark.sql("select * from default.customermysql where city='chennai'").show(10,false);
hivedf.show(5,false)

spark.sql("select * from default.customermysqldscity").show(5,false)
spark.sql("describe default.customermysqldscity").show(5,false)
spark.sql("describe formatted default.customermysqldscity").show(5,false)
spark.sql("select * from default.customermysqldscity").printSchema()

spark.sql("""create external table if not exists default.customermysqldscitypart1 (custid integer
  , firstname string,lastname string, age integer,createdt date)
   partitioned by (city string)
row format delimited fields terminated by ',' 
location '/user/hduser/customermysqldscitypart'""")

spark.sql("""insert into default.customermysqldscitypart1 partition(city) select custid,firstname,lastname,age,createdt,city from dfdbview""")
//or
dsdb.write.mode("overwrite").partitionBy("city").saveAsTable("default.customermysqldscitypart2") // this table can't be read by hive

val hivepartable=spark.sql("select * from default.customermysqldscitypart1");
//or
val hivepartable1=spark.read.table("default.customermysqldscitypart1");



//PARQUET/ORC READ/WRITE -> this data will be exposed to end users (discovery layer)
println("Writing parquet data")
hivedf.write.mode("overwrite").option("compression","none").parquet("hdfs://localhost:54310/user/hduser/hivetoparquet")
println("Writing orc data")
hivedf.write.mode("overwrite").option("compression","none").orc("hdfs://localhost:54310/user/hduser/hivetoorc")

println("Displaying parquet data")
spark.read.option("compression","none").parquet("hdfs://localhost:54310/user/hduser/hivetoparquet").show(10,false)
println("Displaying orc data")
spark.read.option("compression","none").option("timestampFormat","yyyy-MM-dd HH:mm:ss").option("dateFormat","yyyy-dd-mm").orc("hdfs://localhost:54310/user/hduser/hivetoorc").show(10,false)
}   
else
  println("Hive Data load reconcilation failed, not running rest of the steps")
  }
 
  
}









