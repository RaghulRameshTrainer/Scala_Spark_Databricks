# Databricks notebook source
# MAGIC 
# MAGIC %md-sandbox
# MAGIC 
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Project: Exploratory Data Analysis
# MAGIC Perform exploratory data analysis (EDA) to gain insights from a data lake.
# MAGIC 
# MAGIC ## Audience
# MAGIC * Primary Audience: Data Analysts
# MAGIC * Additional Audiences: Data Engineers and Data Scientists
# MAGIC 
# MAGIC ## Prerequisites
# MAGIC * Web browser: **Chrome**
# MAGIC * A cluster configured with **8 cores** and **DBR 6.2**
# MAGIC * Familiarity with <a href="https://www.w3schools.com/sql/" target="_blank">ANSI SQL</a> is required
# MAGIC * Suggested Courses from <a href="https://academy.databricks.com/" target="_blank">Databricks Academy</a>:
# MAGIC   - Spark-SQL
# MAGIC 
# MAGIC ## Instructions
# MAGIC 
# MAGIC In `dbfs:/mnt/training/crime-data-2016`, there are a number of Parquet files containing 2016 crime data from seven United States cities:
# MAGIC 
# MAGIC * New York
# MAGIC * Los Angeles
# MAGIC * Chicago
# MAGIC * Philadelphia
# MAGIC * Dallas
# MAGIC * Boston
# MAGIC 
# MAGIC 
# MAGIC The data is cleaned up a little but has not been normalized. Each city reports crime data slightly differently, so you have to
# MAGIC examine the data for each city to determine how to query it properly.
# MAGIC 
# MAGIC Your job is to use some of this data to gain insights about certain kinds of crimes.

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Setup
# MAGIC 
# MAGIC For each lesson to execute correctly, please make sure to run the **`Classroom-Setup`** cell at the<br/>
# MAGIC start of each lesson (see the next cell) and the **`Classroom-Cleanup`** cell at the end of each lesson.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Step 1
# MAGIC 
# MAGIC Start by creating temporary views for Los Angeles, Philadelphia, and Dallas
# MAGIC 
# MAGIC Use `CREATE TEMPORARY VIEW` to create named views for the files you choose. Use a similar syntax as `CREATE TABLE`:
# MAGIC 
# MAGIC ```
# MAGIC CREATE OR REPLACE TEMPORARY VIEW name
# MAGIC   USING parquet
# MAGIC   OPTIONS (
# MAGIC     ...
# MAGIC   )
# MAGIC ```
# MAGIC 
# MAGIC Use the following view names:
# MAGIC 
# MAGIC | City          | Table Name              | Path to DBFS file
# MAGIC | ------------- | ----------------------- | -----------------
# MAGIC | Los Angeles   | `CrimeDataLosAngeles`   | `dbfs:/mnt/training/crime-data-2016/Crime-Data-Los-Angeles-2016.parquet`
# MAGIC | Philadelphia  | `CrimeDataPhiladelphia` | `dbfs:/mnt/training/crime-data-2016/Crime-Data-Philadelphia-2016.parquet`
# MAGIC | Dallas        | `CrimeDataDallas`       | `dbfs:/mnt/training/crime-data-2016/Crime-Data-Dallas-2016.parquet`
# MAGIC 
# MAGIC 
# MAGIC 
# MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** You learned how to create a table from an external file in [Lesson 3]($./03-Accessing-Data). The syntax is exactly the same, except that you use `CREATE OR REPLACE TEMPORARY VIEW` instead of `CREATE TABLE IF EXISTS`.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Los Angeles

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW CrimeDataLosAngeles
# MAGIC   USING parquet
# MAGIC   OPTIONS (
# MAGIC     path "dbfs:/mnt/training/crime-data-2016/Crime-Data-Los-Angeles-2016.parquet"
# MAGIC   )

# COMMAND ----------

# TEST - Run this cell to test your solution.

rowsLosAngeles = spark.sql('SELECT count(*) FROM CrimeDataLosAngeles').collect()[0][0]
dbTest("SQL-L7-crimeDataLA-count", 217945, rowsLosAngeles)

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Philadelphia

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW CrimeDataPhiladelphia
# MAGIC   USING parquet
# MAGIC   OPTIONS (
# MAGIC     path "dbfs:/mnt/training/crime-data-2016/Crime-Data-Philadelphia-2016.parquet"
# MAGIC   )

# COMMAND ----------

# TEST - Run this cell to test your solution.

rowsPhiladelphia = spark.sql('SELECT count(*) FROM CrimeDataPhiladelphia').collect()[0][0]
dbTest("SQL-L7-crimeDataPA-count", 168664, rowsPhiladelphia)

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Dallas

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW CrimeDataDallas
# MAGIC   USING parquet
# MAGIC   OPTIONS (
# MAGIC     path "dbfs:/mnt/training/crime-data-2016/Crime-Data-Dallas-2016.parquet"
# MAGIC   )

# COMMAND ----------

# TEST - Run this cell to test your solution.

rowsDallas = spark.sql('SELECT count(*) FROM CrimeDataDallas').collect()[0][0]
dbTest("SQL-L7-crimeDataDAL-count", 99642, rowsDallas) 

print("Tests passed!")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Step 2
# MAGIC 
# MAGIC For each table, examine the data to figure out how to extract _robbery_ statistics.
# MAGIC 
# MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> Each city uses different values to indicate robbery. Some cities use "larceny", "burglary", and "robbery".  These challenges are common in data lakes.  To simplify things, restrict yourself to only the word "robbery" (and not attempted-roberty, larceny, or burglary).
# MAGIC 
# MAGIC Explore the data for the three cities until you understand how each city records robbery information. If you don't want to worry about upper- or lower-case, remember that SQL has a `LOWER()` function that converts a column's value to lowercase.
# MAGIC 
# MAGIC Create a temporary view containing only the robbery-related rows, as shown in the table below.
# MAGIC 
# MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** For each table, focus your efforts on the column listed below.
# MAGIC 
# MAGIC Focus on the following columns for each table:
# MAGIC 
# MAGIC | Table Name              | Robbery View Name     | Column
# MAGIC | ----------------------- | ----------------------- | -------------------------------
# MAGIC | `CrimeDataLosAngeles`   | `RobberyLosAngeles`   | `crimeCodeDescription`
# MAGIC | `CrimeDataPhiladelphia` | `RobberyPhiladelphia` | `ucr_general_description`
# MAGIC | `CrimeDataDallas`       | `RobberyDallas`       | `typeOfIncident`

# COMMAND ----------

# MAGIC %md
# MAGIC #### Los Angeles

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM CrimeDataLosAngeles
# MAGIC  LIMIT 2

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberyLosAngeles AS
# MAGIC   SELECT crimeCodeDescription
# MAGIC   FROM CrimeDataLosAngeles
# MAGIC   WHERE lower(crimeCodeDescription) = 'robbery'

# COMMAND ----------

# TEST - Run this cell to test your solution.

totalLosAngeles = spark.sql("SELECT count(*) AS total FROM RobberyLosAngeles").collect()[0].total
dbTest("SQL-L7-robberyDataLA-count", 9048, totalLosAngeles)

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Philadelphia

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberyPhiladelphia AS
# MAGIC   SELECT ucr_general_description
# MAGIC   FROM CrimeDataPhiladelphia
# MAGIC   WHERE lower(ucr_general_description) = 'robbery'

# COMMAND ----------

# TEST - Run this cell to test your solution.

totalPhiladelphia = spark.sql("SELECT count(*) AS total FROM RobberyPhiladelphia").collect()[0].total
dbTest("SQL-L7-robberyDataPA-count", 6149, totalPhiladelphia)

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Dallas

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*) FROM CrimeDataDallas
# MAGIC  WHERE lower(typeOfIncident) LIKE 'robbery%'

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberyDallas AS
# MAGIC   SELECT typeOfIncident
# MAGIC   FROM CrimeDataDallas
# MAGIC   WHERE lower(typeOfIncident) like 'robbery%'

# COMMAND ----------

# TEST - Run this cell to test your solution.

totalDallas = spark.sql("SELECT count(*) AS total FROM RobberyDallas").collect()[0].total
dbTest("SQL-L7-robberyDataDAL-count", 6824, totalDallas)

print("Tests passed!")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Step 3
# MAGIC 
# MAGIC Now that you have views of only the robberies in each city, create temporary views for each city, summarizing the number of robberies in each month.
# MAGIC 
# MAGIC Your views must contain two columns:
# MAGIC * `month`: The month number (e.g., 1 for January, 2 for February, etc.)
# MAGIC * `robberies`: The total number of robberies in the month
# MAGIC 
# MAGIC Use the following temporary view names and date columns:
# MAGIC 
# MAGIC 
# MAGIC | City          | View Name     | Date Column 
# MAGIC | ------------- | ------------- | -------------
# MAGIC | Los Angeles   | `RobberiesByMonthLosAngeles` | `timeOccurred`
# MAGIC | Philadelphia  | `RobberiesByMonthPhiladelphia` | `dispatch_date_time`
# MAGIC | Dallas        | `RobberiesByMonthDallas` | `startingDateTime`
# MAGIC 
# MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> For each city, figure out which column contains the date of the incident. Then, extract the month from that date.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Los Angeles

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM CrimeDataLosAngeles
# MAGIC  LIMIT 2

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberiesByMonthLosAngeles AS
# MAGIC   SELECT month(timeOccurred) as month, count(*) as robberies
# MAGIC   FROM CrimeDataLosAngeles
# MAGIC   WHERE lower(crimeCodeDescription) = 'robbery' 
# MAGIC   GROUP BY month
# MAGIC   ORDER BY month

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT * FROM RobberiesByMonthLosAngeles
# MAGIC  LIMIT 12

# COMMAND ----------

# TEST - Run this cell to test your solution.

rows = spark.sql("SELECT month, robberies FROM RobberiesByMonthLosAngeles ORDER BY month").collect()
la = [ f"{r[0]}: {r[1]}" for r in rows ]

dbTest("SQL-L7-robberyByMonthLA-counts-1", "1: 719", la[0])
dbTest("SQL-L7-robberyByMonthLA-counts-2", "2: 675", la[1])
dbTest("SQL-L7-robberyByMonthLA-counts-3", "3: 709", la[2])
dbTest("SQL-L7-robberyByMonthLA-counts-4", "4: 713", la[3])
dbTest("SQL-L7-robberyByMonthLA-counts-5", "5: 790", la[4])
dbTest("SQL-L7-robberyByMonthLA-counts-6", "6: 698", la[5])
dbTest("SQL-L7-robberyByMonthLA-counts-7", "7: 826", la[6])
dbTest("SQL-L7-robberyByMonthLA-counts-8", "8: 765", la[7])
dbTest("SQL-L7-robberyByMonthLA-counts-9", "9: 722", la[8])
dbTest("SQL-L7-robberyByMonthLA-counts-10", "10: 814", la[9])
dbTest("SQL-L7-robberyByMonthLA-counts-11", "11: 764", la[10])
dbTest("SQL-L7-robberyByMonthLA-counts-12", "12: 853", la[11])

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Philadelphia

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberiesByMonthPhiladelphia AS
# MAGIC   SELECT month(dispatch_date_time) as month, count(*) as robberies
# MAGIC   FROM CrimeDataPhiladelphia
# MAGIC   WHERE lower(ucr_general_description) = 'robbery' 
# MAGIC   GROUP BY month
# MAGIC   ORDER BY month

# COMMAND ----------

# TEST - Run this cell to test your solution.

rows = spark.sql("SELECT month, robberies FROM RobberiesByMonthPhiladelphia ORDER BY month").collect()
philadelphia = [ f"{r[0]}: {r[1]}" for r in rows ]

dbTest("SQL-L7-robberyByMonthPA-counts-1", "1: 520", philadelphia[0])
dbTest("SQL-L7-robberyByMonthPA-counts-2", "2: 416", philadelphia[1])
dbTest("SQL-L7-robberyByMonthPA-counts-3", "3: 432", philadelphia[2])
dbTest("SQL-L7-robberyByMonthPA-counts-4", "4: 466", philadelphia[3])
dbTest("SQL-L7-robberyByMonthPA-counts-5", "5: 533", philadelphia[4])
dbTest("SQL-L7-robberyByMonthPA-counts-6", "6: 509", philadelphia[5])
dbTest("SQL-L7-robberyByMonthPA-counts-7", "7: 537", philadelphia[6])
dbTest("SQL-L7-robberyByMonthPA-counts-8", "8: 561", philadelphia[7])
dbTest("SQL-L7-robberyByMonthPA-counts-9", "9: 514", philadelphia[8])
dbTest("SQL-L7-robberyByMonthPA-counts-10", "10: 572", philadelphia[9])
dbTest("SQL-L7-robberyByMonthPA-counts-11", "11: 545", philadelphia[10])
dbTest("SQL-L7-robberyByMonthPA-counts-12", "12: 544", philadelphia[11])

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Dallas

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberiesByMonthDallas AS
# MAGIC   SELECT month(startingDateTime) as month, count(*) as robberies
# MAGIC   FROM CrimeDataDallas
# MAGIC   WHERE lower(typeOfIncident) like 'robbery%'
# MAGIC   GROUP BY month
# MAGIC   ORDER BY month

# COMMAND ----------

# TEST - Run this cell to test your solution.

rows = spark.sql("SELECT month, robberies FROM RobberiesByMonthDallas ORDER BY month").collect()
dallas = [ f"{r[0]}: {r[1]}" for r in rows ]

dbTest("SQL-L7-robberyByMonthDAL-counts-1", "1: 743", dallas[0])
dbTest("SQL-L7-robberyByMonthDAL-counts-2", "2: 435", dallas[1])
dbTest("SQL-L7-robberyByMonthDAL-counts-3", "3: 412", dallas[2])
dbTest("SQL-L7-robberyByMonthDAL-counts-4", "4: 594", dallas[3])
dbTest("SQL-L7-robberyByMonthDAL-counts-5", "5: 615", dallas[4])
dbTest("SQL-L7-robberyByMonthDAL-counts-6", "6: 495", dallas[5])
dbTest("SQL-L7-robberyByMonthDAL-counts-7", "7: 535", dallas[6])
dbTest("SQL-L7-robberyByMonthDAL-counts-8", "8: 627", dallas[7])
dbTest("SQL-L7-robberyByMonthDAL-counts-9", "9: 512", dallas[8])
dbTest("SQL-L7-robberyByMonthDAL-counts-10", "10: 603", dallas[9])
dbTest("SQL-L7-robberyByMonthDAL-counts-11", "11: 589", dallas[10])
dbTest("SQL-L7-robberyByMonthDAL-counts-12", "12: 664", dallas[11])

print("Tests passed!")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC 
# MAGIC ## Step 4
# MAGIC 
# MAGIC Plot the robberies per month for each of your three cities, producing a plot similar to the following:
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/robberies-by-month.png" style="max-width: 700px; border: 1px solid #aaaaaa; border-radius: 10px 10px 10px 10px"/>
# MAGIC 
# MAGIC When you first run your cell, you'll get an HTML table as the result. To configure the plot,
# MAGIC 
# MAGIC 1. Click the graph button
# MAGIC 2. If the plot doesn't look correct, click the **Plot Options** button
# MAGIC 3. Configure the plot similar to the following example
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/capstone-plot-1.png" style="width: 440px; margin: 10px; border: 1px solid #aaaaaa; border-radius: 10px 10px 10px 10px"/>
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/capstone-plot-2.png" style="width: 268px; margin: 10px; border: 1px solid #aaaaaa; border-radius: 10px 10px 10px 10px"/>
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/capstone-plot-3.png" style="width: 362px; margin: 10px; border: 1px solid #aaaaaa; border-radius: 10px 10px 10px 10px"/>

# COMMAND ----------

# MAGIC %md
# MAGIC #### Los Angeles

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT month, robberies FROM RobberiesByMonthLosAngeles

# COMMAND ----------

# MAGIC %md
# MAGIC #### Philadelphia

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT month, robberies FROM RobberiesByMonthPhiladelphia

# COMMAND ----------

# MAGIC %md
# MAGIC #### Dallas

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT month, robberies FROM RobberiesByMonthDallas

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Step 5
# MAGIC 
# MAGIC Create another temporary view called `CombinedRobberiesByMonth`, that combines all three robberies-per-month views into one.
# MAGIC In creating this view, add a new column called `city`, that identifies the city associated with each row.
# MAGIC The final view will have the following columns:
# MAGIC 
# MAGIC * `city`: The name of the city associated with the row (Use the strings "Los Angeles", "Philadelphia", and "Dallas".)
# MAGIC * `month`: The month number associated with the row
# MAGIC * `robbery`: The number of robbery in that month (for that city)
# MAGIC 
# MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** You may want to use `UNION` in this example to combine the three datasets.
# MAGIC 
# MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** In Databricks, all table schemas are immutable and therefore standard SQL commands such as `ALTER…ADD` and `UPDATE…SET` do not work for adding the new "city" column. 
# MAGIC 
# MAGIC Instead, new columns can be added by simply naming them in the `SELECT` statement within the `CREATE OR REPLACE TEMPORARY VIEW` statement.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberiesByMonthLosAngeles1 AS
# MAGIC   SELECT "Los Angeles" as city, month(timeOccurred) as month, count(*) as robberies
# MAGIC   FROM CrimeDataLosAngeles
# MAGIC   WHERE lower(crimeCodeDescription) = 'robbery' 
# MAGIC   GROUP BY month
# MAGIC   ORDER BY month;
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberiesByMonthPhiladelphia1 AS
# MAGIC   SELECT "Philadelphia" as city, month(dispatch_date_time) as month, count(*) as robberies
# MAGIC   FROM CrimeDataPhiladelphia
# MAGIC   WHERE lower(ucr_general_description) = 'robbery' 
# MAGIC   GROUP BY month
# MAGIC   ORDER BY month;
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberiesByMonthDallas1 AS
# MAGIC   SELECT "Dallas" as city, month(startingDateTime) as month, count(*) as robberies
# MAGIC   FROM CrimeDataDallas
# MAGIC   WHERE lower(typeOfIncident) like 'robbery%'
# MAGIC   GROUP BY month
# MAGIC   ORDER BY month;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW CombinedRobberiesByMonth AS
# MAGIC  SELECT * FROM RobberiesByMonthLosAngeles1
# MAGIC   UNION
# MAGIC  SELECT * FROM RobberiesByMonthPhiladelphia1
# MAGIC   UNION
# MAGIC  SELECT * FROM RobberiesByMonthDallas1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM CombinedRobberiesByMonth
# MAGIC  ORDER BY month, city

# COMMAND ----------

# TEST - Run this cell to test your solution.

rows = spark.sql("SELECT concat(city,'|',month,'|',robberies) FROM CombinedRobberiesByMonth order by robberies, month").collect()

dbTest("SQL-L7-combinedRobberiesByMonth-counts-0",  "Dallas|3|412",  rows[0][0])
dbTest("SQL-L7-combinedRobberiesByMonth-counts-10", "Philadelphia|5|533", rows[10][0])
dbTest("SQL-L7-combinedRobberiesByMonth-counts-20", "Dallas|5|615", rows[20][0])

print("Tests passed!")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Step 6
# MAGIC 
# MAGIC Graph the contents of `CombinedRobberiesByMonth`, producing a graph similar to the following. (The diagram below deliberately
# MAGIC uses different data.)
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/combined-homicides.png" style="width: 800px; border: 1px solid #aaaaaa; border-radius: 10px 10px 10px 10px"/>
# MAGIC 
# MAGIC Adjust the plot options to configure the plot properly, as shown below:
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/capstone-plot-4.png" style="width: 362px; margin: 10px; border: 1px solid #aaaaaa; border-radius: 10px 10px 10px 10px"/>
# MAGIC 
# MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** Order your results by `month`, then `city`.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM CombinedRobberiesByMonth
# MAGIC  ORDER BY month, city

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 7
# MAGIC 
# MAGIC While the above graph is interesting, it's flawed: it's comparing the raw numbers of robberies, not the per capita robbery rates.
# MAGIC 
# MAGIC The table (already created) called `CityData`  contains, among other data, estimated 2016 population values for all United States cities
# MAGIC with populations of at least 100,000. (The data is from [Wikipedia](https://en.wikipedia.org/wiki/List_of_United_States_cities_by_population).)
# MAGIC 
# MAGIC * Use the population values in that table to normalize the robberies so they represent per-capita values (i.e. total robberies divided by population)
# MAGIC * Save your results in a temporary view called `RobberyRatesByCity`
# MAGIC * The robbery rate value must be stored in a new column, `robberyRate`
# MAGIC 
# MAGIC Next, graph the results, as above.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM CityData 
# MAGIC  WHERE city IN('Los Angeles', 'Philadelphia', 'Dallas')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM CombinedRobberiesByMonth
# MAGIC  ORDER BY month, city

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW RobberyRatesByCity AS
# MAGIC SELECT city, month, cast(robberies/3976322 as double) as robberyRate FROM CombinedRobberiesByMonth
# MAGIC  WHERE city = 'Los Angeles'
# MAGIC UNION
# MAGIC SELECT city, month, cast(robberies/1567872 as double) as robberyRate FROM CombinedRobberiesByMonth
# MAGIC  WHERE city = 'Philadelphia'
# MAGIC UNION
# MAGIC SELECT city, month, cast(robberies/1317929 as double) as robberyRate FROM CombinedRobberiesByMonth
# MAGIC  WHERE city = 'Dallas'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM RobberyRatesByCity

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT concat(city,'|',month,'|',cast(robberyRate*10000000 as int)) FROM RobberyRatesByCity order by robberyRate, month

# COMMAND ----------

# TEST - Run this cell to test your solution.

rows = spark.sql("SELECT concat(city,'|',month,'|',cast(robberyRate*10000000 as int)) FROM RobberyRatesByCity order by robberyRate, month").collect()

dbTest("SQL-L7-roberryRatesByCity-counts-0",  "Los Angeles|2|1697", rows[0][0])
dbTest("SQL-L7-roberryRatesByCity-counts-10", "Los Angeles|7|2077", rows[10][0])
dbTest("SQL-L7-roberryRatesByCity-counts-20", "Philadelphia|5|3399", rows[20][0])

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Cleanup<br>
# MAGIC 
# MAGIC Run the **`Classroom-Cleanup`** cell below to remove any artifacts created by this lesson.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Cleanup

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC <h2><img src="https://files.training.databricks.com/images/105/logo_spark_tiny.png"> All done!</h2>
# MAGIC 
# MAGIC Thank you for your participation!

# COMMAND ----------

# MAGIC %md
# MAGIC ## References
# MAGIC 
# MAGIC The crime data used in this notebook comes from the following locations:
# MAGIC 
# MAGIC | City          | Original Data 
# MAGIC | ------------- | -------------
# MAGIC | Boston        | <a href="https://data.boston.gov/group/public-safety" target="_blank">https&#58;//data.boston.gov/group/public-safety</a>
# MAGIC | Chicago       | <a href="https://data.cityofchicago.org/Public-Safety/Crimes-2001-to-present/ijzp-q8t2" target="_blank">https&#58;//data.cityofchicago.org/Public-Safety/Crimes-2001-to-present/ijzp-q8t2</a>
# MAGIC | Dallas        | <a href="https://www.dallasopendata.com/Public-Safety/Police-Incidents/tbnj-w5hb/data" target="_blank">https&#58;//www.dallasopendata.com/Public-Safety/Police-Incidents/tbnj-w5hb/data</a>
# MAGIC | Los Angeles   | <a href="https://data.lacity.org/A-Safe-City/Crime-Data-From-2010-to-Present/y8tr-7khq" target="_blank">https&#58;//data.lacity.org/A-Safe-City/Crime-Data-From-2010-to-Present/y8tr-7khq</a>
# MAGIC | New Orleans   | <a href="https://data.nola.gov/Public-Safety-and-Preparedness/Electronic-Police-Report-2016/4gc2-25he/data" target="_blank">https&#58;//data.nola.gov/Public-Safety-and-Preparedness/Electronic-Police-Report-2016/4gc2-25he/data</a>
# MAGIC | New York      | <a href="https://data.cityofnewyork.us/Public-Safety/NYPD-Complaint-Data-Historic/qgea-i56i" target="_blank">https&#58;//data.cityofnewyork.us/Public-Safety/NYPD-Complaint-Data-Historic/qgea-i56i</a>
# MAGIC | Philadelphia  | <a href="https://www.opendataphilly.org/dataset/crime-incidents" target="_blank">https&#58;//www.opendataphilly.org/dataset/crime-incidents</a>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2020 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>