# Databricks notebook source
# MAGIC 
# MAGIC %md-sandbox
# MAGIC 
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Querying Files with SQL
# MAGIC 
# MAGIC Apache Spark&trade; and Databricks&reg; allow you to use SQL to query large data files.
# MAGIC 
# MAGIC ## In this lesson you:
# MAGIC * Query large files using Spark SQL
# MAGIC * Visualize query results using charts
# MAGIC * Create temporary views to simplify complex queries 
# MAGIC 
# MAGIC ## Audience
# MAGIC * Primary Audience: Data Analysts
# MAGIC * Additional Audiences: Data Engineers and Data Scientists
# MAGIC 
# MAGIC ## Prerequisites
# MAGIC * Web browser: **Chrome**
# MAGIC * A cluster configured with **8 cores** and **DBR 6.2**
# MAGIC * Familiarity with <a href="https://www.w3schools.com/sql/" target="_blank">ANSI SQL</a> is required

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Setup
# MAGIC 
# MAGIC For each lesson to execute correctly, please make sure to run the **`Classroom-Setup`** cell at the<br/>
# MAGIC start of each lesson (see the next cell) and the **`Classroom-Cleanup`** cell at the end of each lesson.

# COMMAND ----------

# MAGIC %run "./Includes/Classroom-Setup"

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/glq179t3sr?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/glq179t3sr?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Querying Tables
# MAGIC This lesson uses the table `People10m`. 
# MAGIC 
# MAGIC The data is fictitious; in particular, the Social Security numbers are fake.

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/wqp0pe2mol?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/wqp0pe2mol?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM People10M

# COMMAND ----------

# MAGIC %md
# MAGIC Take a look at its schema with the `DESCRIBE` function.

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE People10M

# COMMAND ----------

# MAGIC %md
# MAGIC A simple SQL statement can answer the following question:
# MAGIC > According to our data, which women were born after 1990?
# MAGIC 
# MAGIC In Databricks, a `SELECT` statement in a SQL cell is automatically run through Spark, and the results are displayed in an HTML table.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT firstName, middleName, lastName, birthDate
# MAGIC FROM People10M
# MAGIC WHERE year(birthDate) > 1990 AND gender = 'F'

# COMMAND ----------

# MAGIC %md
# MAGIC ### Built-in functions
# MAGIC 
# MAGIC Spark provides a number of <a href="https://spark.apache.org/docs/latest/api/sql/" target="_blank">built-in functions</a>, many of which can be used directly from SQL.  These functions can be used in the `WHERE` expressions to filter data and in `SELECT` expressions to create derived columns.
# MAGIC 
# MAGIC The following SQL statement finds women born after 1990; it uses the `year` function, and it creates a `birthYear` column on the fly.

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/jsd9u7ep3k?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/jsd9u7ep3k?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT firstName, middleName, lastName, year(birthDate) as birthYear, salary 
# MAGIC FROM People10M
# MAGIC WHERE year(birthDate) > 1990 AND gender = 'F'

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/pl68ybkps2?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/pl68ybkps2?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Visualization
# MAGIC 
# MAGIC Databricks provides built-in easy to use visualizations for your data. 
# MAGIC 
# MAGIC Take the query below, and visualize it by selecting the bar graph icon once the table is displayed:
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/visualization-1.png" style="border: 1px solid #aaa; padding: 10px; border-radius: 10px 10px 10px 10px"/>

# COMMAND ----------

# MAGIC %md
# MAGIC How many women were named Mary in seach year?

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT year(birthDate) as birthYear, count(*) AS total
# MAGIC FROM People10M
# MAGIC WHERE firstName = 'Mary' AND gender = 'F'
# MAGIC GROUP BY birthYear
# MAGIC ORDER BY birthYear

# COMMAND ----------

# MAGIC %md
# MAGIC Compare popularity of two names from 1990

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT year(birthDate) as birthYear,  firstName, count(*) AS total
# MAGIC FROM People10M
# MAGIC WHERE (firstName = 'Dorothy' or firstName = 'Donna') AND gender = 'F' AND year(birthDate) > 1990
# MAGIC GROUP BY birthYear, firstName
# MAGIC ORDER BY birthYear, firstName

# COMMAND ----------

# MAGIC %md
# MAGIC ### Temporary Views
# MAGIC 
# MAGIC Temporary views assign a name to a query that will be reused as if they were tables themselves. Unlike tables, temporary views aren't stored on disk and are visible only to the current user. This course makes use of temporary views in the exercises to enable the test cases to verify your queries are correct.
# MAGIC 
# MAGIC A temporary view gives you a name to query from SQL, but unlike a table, it exists only for the duration of your Spark Session. As a result, the temporary view will not carry over when you restart the cluster or switch to a new notebook. It also won't show up in the Data tab that, linked on the left of a Databricks notebook, provides easy access to databases and tables.
# MAGIC 
# MAGIC The following statement creates a temporary view containing the same data.

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/kh6opy2t14?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/kh6opy2t14?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW TheDonnas AS
# MAGIC   SELECT * 
# MAGIC   FROM People10M 
# MAGIC   WHERE firstName = 'Donna'

# COMMAND ----------

# MAGIC %md
# MAGIC To view the contents of temporary view, use select notation

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM TheDonnas

# COMMAND ----------

# MAGIC %md
# MAGIC Create more complex query from People10M table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMPORARY VIEW WomenBornAfter1990 AS
# MAGIC   SELECT firstName, middleName, lastName, year(birthDate) AS birthYear, salary 
# MAGIC   FROM People10M
# MAGIC   WHERE year(birthDate) > 1990 AND gender = 'F'

# COMMAND ----------

# MAGIC %md
# MAGIC Once a temporary view has been created, it can be queried as if it were itself a table. Find out how many Marys are in the WomenBornAfter1990 view.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT birthYear, count(*) 
# MAGIC FROM WomenBornAfter1990 
# MAGIC WHERE firstName = 'Mary' 
# MAGIC GROUP BY birthYear 
# MAGIC ORDER BY birthYear

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Exercise 1
# MAGIC 
# MAGIC Create a temporary view called `Top10FemaleFirstNames` that contains the 10 most common female first names in the `People10M` table. The view must have two columns:
# MAGIC 
# MAGIC * `firstName` - the first name
# MAGIC * `total` - the total number of rows with that first name
# MAGIC 
# MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** You may need to break ties by firstName because some of the totals are identical
# MAGIC 
# MAGIC Display the results.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 1
# MAGIC Create the temporary view.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ANSWER
# MAGIC 
# MAGIC CREATE OR REPLACE TEMPORARY VIEW Top10FemaleFirstNames AS
# MAGIC   SELECT firstName, COUNT(firstName) AS total
# MAGIC   FROM People10M
# MAGIC   WHERE gender = 'F'
# MAGIC   GROUP BY firstName
# MAGIC   ORDER BY total DESC, firstName
# MAGIC   LIMIT 10

# COMMAND ----------

# TEST - Run this cell to test your solution.

resultsDF = spark.sql("SELECT * FROM Top10FemaleFirstNames ORDER BY firstName")
dbTest("SQL-L2-count", 10, resultsDF.count())

results = [ f"{r[0]}, {r[1]}" for r in resultsDF.collect()]
dbTest("SQL-L2-names-0", "Alesha, 1368", results[0])
dbTest("SQL-L2-names-1", "Alice, 1384", results[1])
dbTest("SQL-L2-names-2", "Bridgette, 1373", results[2])
dbTest("SQL-L2-names-3", "Cristen, 1375", results[3])
dbTest("SQL-L2-names-4", "Jacquelyn, 1381", results[4])
dbTest("SQL-L2-names-5", "Katherin, 1373", results[5])
dbTest("SQL-L2-names-6", "Lashell, 1387", results[6])
dbTest("SQL-L2-names-7", "Louie, 1382", results[7])
dbTest("SQL-L2-names-8", "Lucille, 1384", results[8])
dbTest("SQL-L2-names-9", "Sharyn, 1394", results[9])

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2
# MAGIC 
# MAGIC Display the contents of the temporary view.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ANSWER
# MAGIC 
# MAGIC SELECT * FROM Top10FemaleFirstNames

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC * Spark SQL queries tables that are backed by physical files
# MAGIC * You can visualize the results of your queries with built-in Databricks graphs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Review Questions
# MAGIC **Q:** What is the prefix used in databricks cells to execute SQL queries?  
# MAGIC **A:** `%sql`
# MAGIC 
# MAGIC **Q:** How do temporary views differ from tables?  
# MAGIC **A:** Tables are visible to all users, can be accessed from any notebook, and persist across server resets.  Temporary views are only visible to the current user, in the current notebook, and are gone once the spark session ends.
# MAGIC 
# MAGIC **Q:** What is the SQL syntax to create a temporary view?  
# MAGIC **A:** ```CREATE OR REPLACE TEMPORARY VIEW <<ViewName>> AS <<Query>>```

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Cleanup<br>
# MAGIC 
# MAGIC Run the **`Classroom-Cleanup`** cell below to remove any artifacts created by this lesson.

# COMMAND ----------

# MAGIC %run "./Includes/Classroom-Cleanup"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Steps
# MAGIC 
# MAGIC Start the next lesson, [Aggregations, JOINs and Nested Queries]($./SSQL 03 - Joins Aggregations ).

# COMMAND ----------

# MAGIC %md
# MAGIC ## Additional Topics & Resources
# MAGIC 
# MAGIC * <a href="https://docs.databricks.com/spark/latest/spark-sql/index.html" target="_blank">Spark SQL Reference</a>
# MAGIC * <a href="http://spark.apache.org/docs/latest/sql-programming-guide.html" target="_blank">Spark SQL, DataFrames and Datasets Guide</a>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2020 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>