# Databricks notebook source

try:
  dbutils.fs.unmount("/mnt/temp-training")
except:
  pass # ignored

spark.sql("DROP DATABASE IF EXISTS junk CASCADE")
spark.sql("DROP DATABASE IF EXISTS databricks CASCADE")

classroomCleanup(daLogger, courseType, username, moduleName, lessonName, True)

# COMMAND ----------

showStudentSurvey()
