# Databricks notebook source
# MAGIC 
# MAGIC %md-sandbox
# MAGIC 
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Challenge Exercises

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Setup
# MAGIC 
# MAGIC For each lesson to execute correctly, please make sure to run the **`Classroom-Setup`** cell at the<br/>
# MAGIC start of each lesson (see the next cell) and the **`Classroom-Cleanup`** cell at the end of each lesson.

# COMMAND ----------

# MAGIC %run "../Includes/Classroom-Setup"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Challenge Exercise 4
# MAGIC 
# MAGIC Use the `SSANames` table to find the most popular first name for girls in 1885, 1915, 1945, 1975, and 2005.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Step 1
# MAGIC Create a temporary view called `HistoricNames` where:
# MAGIC 0. The table `HistoricNames` is created using a **single** SQL query.
# MAGIC 0. The result has three columns:
# MAGIC   * `firstName`
# MAGIC   * `year`
# MAGIC   * `total`
# MAGIC 
# MAGIC <img alt="Hint" title="Hint" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.3em" src="https://files.training.databricks.com/static/images/icon-light-bulb.svg"/>&nbsp;**Hint:** Explore the data before crafting your solution.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TODO
# MAGIC 
# MAGIC FILL_IN

# COMMAND ----------

# TEST - Run this cell to test your solution.

rows = spark.sql("select concat(firstName,'|',year,'|',total) from HistoricNames order by total").collect()

dbTest("SQL-L3-Opt-historicNames-0", "Mary|1885|9128", rows[0][0])
dbTest("SQL-L3-Opt-historicNames-1", "Emily|2005|23928", rows[1][0])
dbTest("SQL-L3-Opt-historicNames-2", "Jennifer|1975|58185", rows[2][0])
dbTest("SQL-L3-Opt-historicNames-3", "Mary|1915|58187", rows[3][0])
dbTest("SQL-L3-Opt-historicNames-4", "Mary|1945|59284", rows[4][0])

print("Tests passed!")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Step 2
# MAGIC Display the table `HistoricNames`.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TODO
# MAGIC 
# MAGIC FILL_IN

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Cleanup<br>
# MAGIC 
# MAGIC Run the **`Classroom-Cleanup`** cell below to remove any artifacts created by this lesson.

# COMMAND ----------

# MAGIC %run ../Includes/Classroom-Cleanup

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Steps
# MAGIC * Start one of the following lessons:
# MAGIC   - [Accessing Data - Amazon S3]($../SSQL 04a - Accessing Data - Amazon S3).
# MAGIC   - [Accessing Data - Azure Blob]($../SSQL 04b - Accessing Data - Azure Blob).

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2020 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>