# Databricks notebook source
# MAGIC 
# MAGIC %md-sandbox
# MAGIC 
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Accessing Data
# MAGIC 
# MAGIC Apache Spark&trade; and Databricks&reg; have numerous ways to access your data.
# MAGIC 
# MAGIC ## In this lesson you
# MAGIC * Create a table from an existing file
# MAGIC * Create a table by uploading a data file from your local machine
# MAGIC * Mount an S3 bucket to DBFS
# MAGIC * Create tables for Databricks data sets to use throughout the course
# MAGIC 
# MAGIC ## Audience
# MAGIC * Primary Audience: Data Analysts
# MAGIC * Additional Audiences: Data Engineers and Data Scientists
# MAGIC 
# MAGIC ## Prerequisites
# MAGIC * Web browser: **Chrome**
# MAGIC * A cluster configured with **8 cores** and **DBR 6.2**
# MAGIC * Familiarity with <a href="https://www.w3schools.com/sql/" target="_blank">ANSI SQL</a> is required

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Setup
# MAGIC 
# MAGIC For each lesson to execute correctly, please make sure to run the **`Classroom-Setup`** cell at the<br/>
# MAGIC start of each lesson (see the next cell) and the **`Classroom-Cleanup`** cell at the end of each lesson.

# COMMAND ----------

# MAGIC %run "./Includes/Classroom-Setup"

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/nf81as9ya0?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/nf81as9ya0?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create a table from an existing file
# MAGIC 
# MAGIC DBFS (the <a href="https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html" target="_blank">Databricks File System</a>) is the built-in, S3-backed, alternative to 
# MAGIC HDFS (the <a href="http://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-hdfs/HdfsUserGuide.html" target="_blank">Hadoop Distributed File System</a>).
# MAGIC 
# MAGIC Creating a table from an existing file in DBFS allows you to access the file as if it were a Spark table. It does **not** copy any data.

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/ysgdonjuk6?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/ysgdonjuk6?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC The example below creates a table from the **ip-geocode.parquet** file (if it doesn't exist).
# MAGIC 
# MAGIC For Parquet files, you need to specify only one option: the path to the file.
# MAGIC 
# MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> A Parquet "file" is actually a collection of files stored in a single directory.  The Parquet format offers features making it the ideal choice for storing "big data" on distributed file systems. For more information, see <a href="https://parquet.apache.org/" target="_blank">Apache Parquet</a>.
# MAGIC 
# MAGIC You can create a table from an existing DBFS file with a simple SQL `CREATE TABLE` statement. If you don't select a database, the database called "default" is used. Here, we'll use a database called "junk", to remind us to delete these tables later.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS junk;
# MAGIC 
# MAGIC USE junk;
# MAGIC 
# MAGIC CREATE TABLE IF NOT EXISTS IPGeocode
# MAGIC   USING parquet
# MAGIC   OPTIONS (
# MAGIC     path "dbfs:/mnt/training/ip-geocode.parquet"
# MAGIC   )

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Now the table has been defined. You can see it in Databricks.
# MAGIC 0. Click the **Data** icon on the left sidebar<br/>
# MAGIC <div><img src="https://files.training.databricks.com/images/eLearning/data-tab.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px"/></div>
# MAGIC 0. Select the database **junk**.
# MAGIC 0. Select the table **ipgeocode**.  
# MAGIC <img alt="Caution" title="Caution" style="vertical-align: text-bottom; position: relative; height:1.3em; top:0.0em" src="https://files.training.databricks.com/static/images/icon-warning.svg"/> Right-click and open in a new tab, so you don't lose your place in this notebook
# MAGIC <div><img src="https://files.training.databricks.com/images/eLearning/database.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px"/></div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC You see the schema of the table, along with a sample of its data.
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/db-table-example-1.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px"/>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Using A Personal Database
# MAGIC 
# MAGIC Any tables created or droped will be done so in the **`junk`** database.
# MAGIC 
# MAGIC However, every user of this system, if running this same code, will be altering the same tables. 
# MAGIC 
# MAGIC In cases such as this one, it is often better to use a "personal" database.
# MAGIC 
# MAGIC For this reason, we will switch back to your personal database now.
# MAGIC 
# MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> We need to use the Spark programming API here only because we are unable to parameterize a **`%sql`** cell with the database we setup for you (as represtend by **`databaseName`**).

# COMMAND ----------

# Programatically exectue a similar SQL command as above
spark.sql(f"USE {databaseName}")


# COMMAND ----------

spark.sql(f"USE junk")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM ipgeocode;

# COMMAND ----------

# MAGIC %md
# MAGIC ### File formats other than Parquet
# MAGIC 
# MAGIC You can also create a table from other file formats. 
# MAGIC 
# MAGIC One common format is CSV (comma-separated-values) for which you can specify:
# MAGIC * The file's delimiter, the default is "**,**"
# MAGIC * Whether the file has a header or not, the default is **false**
# MAGIC * Whether or not to infer the schema, the default is **false**

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/brunhjed4t?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/brunhjed4t?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC In order to know which options to use, look at the first couple of lines of the file.
# MAGIC 
# MAGIC Take a look at the head of the file **/mnt/training/bikeSharing/data-001/day.csv.**

# COMMAND ----------

# MAGIC %fs head /mnt/training/bikeSharing/data-001/day.csv --maxBytes=492

# COMMAND ----------

# MAGIC %md
# MAGIC Spark can create a table from that CSV file, as well.
# MAGIC 
# MAGIC As you can see above:
# MAGIC * There is a header
# MAGIC * The file is comma separated (the default)
# MAGIC * Let Spark infer what the schema is

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS BikeSharingDay
# MAGIC   USING csv
# MAGIC   OPTIONS (
# MAGIC     path "/mnt/training/bikeSharing/data-001/day.csv",
# MAGIC     inferSchema "true",
# MAGIC     header "true"
# MAGIC   )

# COMMAND ----------

# MAGIC %md
# MAGIC Now the table is defined, view its contents with a simple select statement.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM BikeSharingDay

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Next, drop the table.
# MAGIC 
# MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> This does not delete the file from which the table was created.  Rather, it simply removes the table definition from Spark.

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE BikeSharingDay

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upload a local file as a table
# MAGIC 
# MAGIC The last two examples use files already loaded on the "server."
# MAGIC 
# MAGIC Databricks also supports creating tables by uploading files. 
# MAGIC 
# MAGIC Next, download the following file to your local machine: <a href="https://s3-us-west-2.amazonaws.com/databricks-corp-training/common/dataframes/state-income.csv">state-income.csv</a>

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/anplj4runo?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/anplj4runo?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Select **Data** from the sidebar, and click on the **junk** database.
# MAGIC 
# MAGIC This time, select the **+** icon to create a new table.
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/create-table-1-junk-db.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px"/>
# MAGIC 
# MAGIC Ensure that **Upload File** is selected. Then, select the **state-income.csv** file from your machine, or drag-and-drop the file to initiate the upload.
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/create-table-2.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px"/>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Once the file is uploaded, create the actual table:
# MAGIC 
# MAGIC 1. Click the **Create Table with UI** button  
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/create-table-3.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; margin: 20px"/>
# MAGIC 2. In the drop-down dialog, select a cluster
# MAGIC 3. Click the **Preview Table** button 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/create-table-4.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; margin: 20px"/>
# MAGIC 4. Another dialog will drop down. Choose the **junk** database
# MAGIC 5. Select the **First row is header** checkbox
# MAGIC 6. Click the **Create Table** button
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/create-table-5.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; margin-top: 20px"/>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Once Databricks finishes processing the file, you'll see another table preview.
# MAGIC 
# MAGIC <img alt="Caution" title="Caution" style="vertical-align: text-bottom; position: relative; height:1.3em; top:0.0em" src="https://files.training.databricks.com/static/images/icon-warning.svg"/> Databricks tries to choose a table name that doesn't clash with tables created by other users. However, a name clash is still possible. If the table already exists, you'll see an error like the following:
# MAGIC 
# MAGIC <img src="https://files.training.databricks.com/images/eLearning/create-table-6.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; margin-top: 20px; padding: 10px"/>
# MAGIC 
# MAGIC If that happens, just type in a different table name, and try again.

# COMMAND ----------

# MAGIC %md
# MAGIC Next, drop the table to ensure other users don't have a name conflict when uploading their tables.

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS state_income1

# COMMAND ----------

# MAGIC %md
# MAGIC ### How to mount an S3 bucket to DBFS
# MAGIC 
# MAGIC Amazon Web Services (AWS) provides cloud file storage in the form of the Amazon Simple Storage Service (S3).  Files are stored in "buckets."
# MAGIC If you have an S3 account, you can create a bucket, store data files in that bucket, and mount the bucket as a DBFS directory. 
# MAGIC 
# MAGIC Once the bucket is mounted as a DBFS directory, you can access it without exposing your S3 keys.

# COMMAND ----------

# MAGIC %md
# MAGIC <iframe  
# MAGIC src="//fast.wistia.net/embed/iframe/yfd41f8du5?videoFoam=true"
# MAGIC style="border:1px solid #1cb1c2;"
# MAGIC allowtransparency="true" scrolling="no" class="wistia_embed"
# MAGIC name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen
# MAGIC oallowfullscreen msallowfullscreen width="640" height="360" ></iframe>
# MAGIC <div>
# MAGIC <a target="_blank" href="https://fast.wistia.net/embed/iframe/yfd41f8du5?seo=false">
# MAGIC   <img alt="Opens in new tab" src="https://files.training.databricks.com/static/images/external-link-icon-16x16.png"/>&nbsp;Watch full-screen.</a>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC Take a look at the buckets already mounted to your DBFS:

# COMMAND ----------

# MAGIC %fs mounts

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Mount your own bucket to a new mount point. To do so, use the `dbutils.fs.mount(..)` function.
# MAGIC 
# MAGIC Below, mount a Databricks S3 bucket (using a read-only access and secret key pair), access one of the files in the bucket as a DBFS path, then unmount the bucket.
# MAGIC 
# MAGIC <img alt="Caution" title="Caution" style="vertical-align: text-bottom; position: relative; height:1.3em; top:0.0em" src="https://files.training.databricks.com/static/images/icon-warning.svg"/> The mount point **must** start with `/mnt/`.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC Create the mount point with `%fs mount`.
# MAGIC 
# MAGIC <img alt="Caution" title="Caution" style="vertical-align: text-bottom; position: relative; height:1.3em; top:0.0em" src="https://files.training.databricks.com/static/images/icon-warning.svg"/> If the directory was already mounted, you would receive the following error:
# MAGIC 
# MAGIC > Directory already mounted: /mnt/temp-training
# MAGIC 
# MAGIC In this case, use a different mount point such as `temp-training-2`, and ensure you update all three references below.

# COMMAND ----------

# MAGIC %fs mount s3a://AKIAJBRYNXGHORDHZB4A:a0BzE1bSegfydr3%2FGE3LSPM6uIV5A4hOUfpH8aFF@databricks-corp-training/common /mnt/temp-training

# COMMAND ----------

# MAGIC %md
# MAGIC List the contents of the directory you just mounted:

# COMMAND ----------

# MAGIC %fs ls /mnt/temp-training

# COMMAND ----------

# MAGIC %md
# MAGIC Take a peek at the head of the file `auto-mpg.csv`:

# COMMAND ----------

# MAGIC %fs head /mnt/temp-training/auto-mpg.csv

# COMMAND ----------

# MAGIC %md
# MAGIC Now you are done, unmount the directory.

# COMMAND ----------

# %fs unmount /mnt/temp-training

# COMMAND ----------

# MAGIC %md
# MAGIC Create your own access keys in AWS for your own S3 buckets and mount them the same way.
# MAGIC 
# MAGIC This allows access to your S3 data directly from Databricks distributed file system (DBFS).
# MAGIC 
# MAGIC Once mounted, you can delete the single cell that contained your keys or even the entire notebook protecting your keys from unscrupulous actors.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summary
# MAGIC 
# MAGIC Databricks allows you to:
# MAGIC   * Create tables from existing data
# MAGIC   * Create tables from uploaded files
# MAGIC   * Mount your own S3 buckets

# COMMAND ----------

# MAGIC %md
# MAGIC ## Review Questions
# MAGIC **Q:** How can you see which tables have been created?    
# MAGIC **A:** Go to the **Data** section using the button-bar to the left.
# MAGIC 
# MAGIC **Q:** What is Amazon S3?  
# MAGIC **A:** Amazon S3 stands for Simple Storage Service.  It provides cloud-optimized storage of large data files that easily scales with your storage needs.
# MAGIC 
# MAGIC **Q:** What is DBFS?  
# MAGIC **A:** DBFS stands for Databricks File System.  DBFS provides for the cloud what the Hadoop File System (HDFS) provides for local spark deployments.  DBFS uses Amazon S3 and makes it easy to access files by name.
# MAGIC 
# MAGIC **Q:** Which is more efficient to query, a parquet file or a CSV file?  
# MAGIC **A:** Parquet files are highly optimized binary formats for storing tables.  The overhead is less than required to parse a CSV file.  Parquet is the big data analogue to CSV as it is optimized, distributed, and more fault tolerant than CSV files.
# MAGIC 
# MAGIC **Q:** How can you create a new table?  
# MAGIC **A:** Create new tables by either:
# MAGIC * Uploading a new file using the Data tab on the left.
# MAGIC * Mounting an existing file from DBFS.
# MAGIC 
# MAGIC **Q:** What is the SQL syntax for defining a table in Spark from an existing parquet file in DBFS?  
# MAGIC **A:** ```CREATE TABLE IF NOT EXISTS IPGeocode
# MAGIC USING parquet
# MAGIC OPTIONS (
# MAGIC   path "dbfs:/mnt/training/ip-geocode.parquet"
# MAGIC )```

# COMMAND ----------

# MAGIC %md
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Classroom-Cleanup<br>
# MAGIC 
# MAGIC Run the **`Classroom-Cleanup`** cell below to remove any artifacts created by this lesson.

# COMMAND ----------

# MAGIC %run "./Includes/Classroom-Cleanup"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Next Steps
# MAGIC 
# MAGIC Start the next lesson, [Querying JSON & Hierarchical Data with SQL]($./SSQL 05 - Querying JSON).

# COMMAND ----------

# MAGIC %md
# MAGIC ## Additional Topics & Resources
# MAGIC 
# MAGIC * <a href="https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html" target="_blank">The Databricks DBFS File System</a>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2020 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>